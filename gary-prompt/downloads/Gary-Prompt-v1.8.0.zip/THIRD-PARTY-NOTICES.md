# Third-party notices

Gary Prompt 不是 MiniMax、Microsoft、Google、ByteDance 或 Seedance 的官方产品。

## MiniMax H3 prompting materials

Gary Prompt 中标记为“MiniMax 官方开源”的 Skills 根据 MiniMax-AI 发布的 MiniMax H3 Skills 整理并适配为浏览器侧边栏工作流：

- Source: https://github.com/MiniMax-AI/MiniMax-H3/tree/main/skills
- Model repository: https://huggingface.co/MiniMaxAI/MiniMax-H3
- License reference: https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE

MiniMax H3 项目 README 指向 MiniMax H3 Community License Agreement。发布者应在正式发布、商业化或改变分发方式之前复核当时有效的许可证，并履行相应的署名、通知和商业使用条件。

Built with MiniMax H3.

## Gary Prompt adaptations

Gary Prompt 对上述材料做了分类、中文说明、输出清理、用户补充优先级、图像/视频素材路由、任务队列和通用 H3 转换适配。这些适配不代表 MiniMax 对 Gary Prompt 的认可、认证或赞助。
