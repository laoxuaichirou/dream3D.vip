(function () {
  class GaryApiError extends Error {
    constructor(message, options) {
      super(message);
      this.name = "GaryApiError";
      this.category = options?.category || "unknown";
      this.status = options?.status || 0;
      this.retryable = Boolean(options?.retryable);
      this.retryAfterMs = Number.isFinite(options?.retryAfterMs) ? options.retryAfterMs : null;
      this.detail = options?.detail || "";
    }
  }

  function retryAfterMs(response) {
    const value = response.headers?.get?.("retry-after");
    if (!value) return null;
    const seconds = Number(value);
    if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
    const date = Date.parse(value);
    return Number.isFinite(date) ? Math.max(0, date - Date.now()) : null;
  }

  function apiError(category, status, detail, retryable, retryAfter) {
    const suffix = detail ? ` 服务商返回：${String(detail).slice(0, 500)}` : "";
    const zhMessages = {
      billing: `API 余额不足、套餐已到期或调用额度已用完。请充值或续费后，在失败任务上点击“重试”。${suffix}`,
      auth: `API Key 无效、已过期，或当前 Key 没有接口权限。请检查 Key 与服务区域后重试。${suffix}`,
      rate_limit: `API 请求过于频繁或触发额度限流，将按服务商建议等待后自动重试。${suffix}`,
      server: `API 服务商暂时异常（HTTP ${status}），将自动重试；持续失败时请稍后再试或更换服务商。${suffix}`,
      timeout: `API 请求超过设置的单次等待时间。可能是网络波动或模型生成过慢；可调高超时后手动重试。${suffix}`,
      network: `网络连接中断、服务商不可达，或浏览器跨域请求被阻止。请检查网络与 API 地址后重试。${suffix}`,
      model: `模型不存在、已下线，或当前账户没有该模型权限。请刷新模型列表或更换模型。${suffix}`,
      content: `请求被服务商的内容安全策略拒绝。请调整提示词或参考素材后重试。${suffix}`,
      bad_request: `API 参数或素材格式不被当前模型接受。请检查模型、接口地址和上传素材。${suffix}`,
      response: `API 返回不完整或没有可读取的文本，可能是响应中途断开。将尝试重新请求。${suffix}`,
      unknown: `API 调用失败。${suffix}`
    };
    const englishSuffix = detail ? ` Provider response: ${String(detail).slice(0, 500)}` : "";
    const enMessages = {
      billing: `Insufficient API balance, expired plan, or exhausted quota. Top up or renew, then click Retry on the failed job.${englishSuffix}`,
      auth: `The API key is invalid, expired, or lacks permission. Check the key and service region, then retry.${englishSuffix}`,
      rate_limit: `The API is rate-limited. Gary Prompt will wait and retry automatically.${englishSuffix}`,
      server: `The API provider is temporarily unavailable (HTTP ${status}). Gary Prompt will retry automatically.${englishSuffix}`,
      timeout: `The request exceeded the configured timeout. The network may be unstable or the model may be slow; increase the timeout and retry.${englishSuffix}`,
      network: `The network was interrupted, the provider is unreachable, or browser CORS blocked the request. Check the connection and endpoint.${englishSuffix}`,
      model: `The model does not exist, was retired, or is not enabled for this account. Refresh the model list or select another model.${englishSuffix}`,
      content: `The provider rejected the request under its content-safety policy. Adjust the prompt or reference media and retry.${englishSuffix}`,
      bad_request: `The current model rejected the request parameters or media format. Check the model, endpoint, and uploaded files.${englishSuffix}`,
      response: `The API returned an incomplete response or no readable text. Gary Prompt will retry the request.${englishSuffix}`,
      unknown: `API request failed.${englishSuffix}`
    };
    const messages = window.GaryI18n?.getLocale?.() === "en" ? enMessages : zhMessages;
    return new GaryApiError(messages[category] || messages.unknown, { category, status, detail, retryable, retryAfterMs: retryAfter });
  }

  function classifyHttpError(status, detail, response) {
    const lower = String(detail || "").toLowerCase();
    const after = retryAfterMs(response);
    if (status === 402 || /insufficient|balance|billing|payment|credit|quota exhausted|欠费|余额不足|额度(不足|用完)|套餐.*(到期|过期)/i.test(lower)) return apiError("billing", status, detail, false);
    if (status === 401 || /invalid.*(api|key)|api key.*invalid|unauthorized|authentication|鉴权|密钥.*(错误|无效|过期)/i.test(lower)) return apiError("auth", status, detail, false);
    if (status === 429 || /rate.?limit|too many requests|rpm|tpm|限流|请求过于频繁/i.test(lower)) return apiError("rate_limit", status, detail, true, after);
    if (status === 408 || status === 504) return apiError("timeout", status, detail, true, after);
    if (status >= 500) return apiError("server", status, detail, true, after);
    if (status === 404 || /model.*(not found|does not exist|unavailable)|模型.*(不存在|下线|无权限)/i.test(lower)) return apiError("model", status, detail, false);
    if (/safety|moderation|content policy|blocked|敏感|内容安全|审核/i.test(lower)) return apiError("content", status, detail, false);
    if (status === 403) return apiError("auth", status, detail, false);
    if ([400, 409, 415, 422].includes(status)) return apiError("bad_request", status, detail, false);
    return apiError("unknown", status, detail, false);
  }

  function normalizeError(error, timeoutMs) {
    if (error instanceof GaryApiError) return error;
    const message = String(error?.message || error || "");
    if (error?.name === "AbortError") return apiError("timeout", 0, `已等待 ${Math.round(timeoutMs / 1000)} 秒`, true);
    if (/failed to fetch|networkerror|network request failed|load failed|internet disconnected|网络/i.test(message) || error instanceof TypeError) return apiError("network", 0, message, true);
    if (/没有找到文本结果|没有可读取|unexpected end|json.*(invalid|parse)|不完整/i.test(message)) return apiError("response", 0, message, true);
    return apiError("unknown", 0, message, false);
  }

  async function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  async function withRetries(config, options, operation) {
    const retries = Math.max(0, Math.min(2, Number(config.retryCount ?? 2)));
    const maxAttempts = retries + 1;
    const timeoutMs = Math.max(1000, Number(config.timeoutMs || 240000));
    let lastError;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await operation(controller.signal);
      } catch (rawError) {
        lastError = normalizeError(rawError, timeoutMs);
        if (!lastError.retryable || attempt >= maxAttempts) throw lastError;
        const fallback = Math.min(30000, 1400 * (2 ** (attempt - 1)) + Math.round(Math.random() * 500));
        const delayMs = lastError.retryAfterMs === null ? fallback : Math.min(60000, lastError.retryAfterMs);
        options?.onRetry?.({ attempt, nextAttempt: attempt + 1, maxAttempts, delayMs, category: lastError.category, message: lastError.message });
        await wait(delayMs);
      } finally {
        clearTimeout(timeout);
      }
    }
    throw lastError;
  }

  function stripDataUrl(dataUrl) {
    const match = /^data:([^;]+);base64,(.+)$/s.exec(dataUrl || "");
    if (!match) throw new Error("素材编码无效，请重新上传。");
    return { mimeType: match[1], data: match[2] };
  }

  function messageFromOpenAIResponse(data) {
    if (typeof data.output_text === "string" && data.output_text.trim()) return data.output_text.trim();
    const text = (data.output || [])
      .flatMap(item => item.content || [])
      .map(part => part.text || part.output_text || "")
      .filter(Boolean)
      .join("\n");
    if (text.trim()) return text.trim();
    throw new Error("API 已返回，但没有找到文本结果。");
  }

  function messageFromCompatibleResponse(data) {
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content === "string" && content.trim()) return content.trim();
    if (Array.isArray(content)) {
      const text = content.map(item => item.text || item.content || "").join("\n").trim();
      if (text) return text;
    }
    if (typeof data?.choices?.[0]?.text === "string") return data.choices[0].text.trim();
    throw new Error("API 已返回，但没有找到文本结果。");
  }

  async function parseResponse(response) {
    const text = await response.text();
    let data;
    try { data = text ? JSON.parse(text) : {}; } catch (_) { data = { raw: text }; }
    if (!response.ok) {
      const detail = data?.error?.message || data?.message || data?.raw || `${response.status} ${response.statusText}`;
      throw classifyHttpError(response.status, detail, response);
    }
    const baseCode = Number(data?.base_resp?.status_code || 0);
    if (baseCode) {
      const detail = data?.base_resp?.status_msg || data?.message || `业务错误码 ${baseCode}`;
      if (baseCode === 1008) throw apiError("billing", 200, detail, false);
      if (baseCode === 1004) throw apiError("auth", 200, detail, false);
      if (baseCode === 1002) throw apiError("rate_limit", 200, detail, true);
      if (baseCode === 1027) throw apiError("content", 200, detail, false);
      if (baseCode === 1013) throw apiError("server", 200, detail, true);
      if ([1039, 2013].includes(baseCode)) throw apiError("bad_request", 200, detail, false);
      throw classifyHttpError(400, detail, response);
    }
    if (data?.error && !data?.choices && !data?.output && !data?.candidates && !data?.content) {
      const detail = data.error.message || data.error.code || data.message || "服务商返回业务错误";
      throw classifyHttpError(Number(data.error.status || data.status || 400), detail, response);
    }
    return data;
  }

  function bearerHeaders(apiKey, extra) {
    return Object.assign({
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    }, extra || {});
  }

  async function callOpenAIResponses(config, systemPrompt, userText, media, signal) {
    const content = [{ type: "input_text", text: userText }];
    media.forEach(item => content.push({ type: "input_image", image_url: item.dataUrl, detail: "high" }));
    const body = {
      model: config.model,
      instructions: systemPrompt,
      input: [{ role: "user", content }],
      max_output_tokens: 12000
    };
    if (/^gpt-5\.6/.test(config.model)) body.reasoning = { effort: "medium" };
    const response = await fetch(config.endpoint, {
      method: "POST",
      headers: bearerHeaders(config.apiKey),
      body: JSON.stringify(body),
      signal
    });
    return messageFromOpenAIResponse(await parseResponse(response));
  }

  async function callOpenAICompatible(config, systemPrompt, userText, media, signal) {
    const userContent = media.length
      ? [{ type: "text", text: userText }, ...media.map(item => ({ type: "image_url", image_url: { url: item.dataUrl } }))]
      : userText;
    const headers = bearerHeaders(config.apiKey);
    if (/openrouter\.ai/i.test(config.endpoint)) {
      headers["HTTP-Referer"] = "https://dream3d.vip/";
      headers["X-Title"] = "Gary Prompt";
    }
    const response = await fetch(config.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent }
        ],
        max_tokens: 12000,
        temperature: 0.55
      }),
      signal
    });
    return messageFromCompatibleResponse(await parseResponse(response));
  }

  async function callAnthropic(config, systemPrompt, userText, media, signal) {
    const content = [{ type: "text", text: userText }];
    media.forEach(item => {
      const parsed = stripDataUrl(item.dataUrl);
      content.push({
        type: "image",
        source: { type: "base64", media_type: parsed.mimeType, data: parsed.data }
      });
    });
    const response = await fetch(config.endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": config.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: config.model,
        max_tokens: 12000,
        system: systemPrompt,
        messages: [{ role: "user", content }]
      }),
      signal
    });
    const data = await parseResponse(response);
    const text = (data.content || []).filter(item => item.type === "text").map(item => item.text).join("\n").trim();
    if (!text) throw new Error("Claude 已返回，但没有找到文本结果。");
    return text;
  }

  function geminiBase(endpoint) {
    return endpoint.replace(/\/$/, "").replace(/\/models$/, "");
  }

  async function callGemini(config, systemPrompt, userText, media, signal) {
    const parts = [{ text: userText }];
    media.forEach(item => {
      const parsed = stripDataUrl(item.dataUrl);
      parts.push({ inlineData: { mimeType: parsed.mimeType, data: parsed.data } });
    });
    const url = `${geminiBase(config.endpoint)}/models/${encodeURIComponent(config.model)}:generateContent?key=${encodeURIComponent(config.apiKey)}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: "user", parts }],
        generationConfig: { temperature: 0.55, maxOutputTokens: 12000 }
      }),
      signal
    });
    const data = await parseResponse(response);
    const text = (data?.candidates?.[0]?.content?.parts || []).map(part => part.text || "").join("\n").trim();
    if (!text) {
      const reason = data?.promptFeedback?.blockReason;
      throw new Error(reason ? `Gemini 未生成结果：${reason}` : "Gemini 已返回，但没有找到文本结果。");
    }
    return text;
  }

  async function generate(config, systemPrompt, userText, media, options) {
    if (!config.apiKey) throw new Error("请先在设置中填写 API Key。");
    if (!config.endpoint) throw new Error("请先填写 API 地址。");
    if (!config.model) throw new Error("请选择或填写模型 ID。");
    const safeMedia = Array.isArray(media) ? media : [];
    return withRetries(config, options, signal => {
      if (config.type === "openai-responses") return callOpenAIResponses(config, systemPrompt, userText, safeMedia, signal);
      if (config.type === "anthropic") return callAnthropic(config, systemPrompt, userText, safeMedia, signal);
      if (config.type === "gemini") return callGemini(config, systemPrompt, userText, safeMedia, signal);
      return callOpenAICompatible(config, systemPrompt, userText, safeMedia, signal);
    });
  }

  function isStrongModel(id, providerId, raw) {
    const name = String(id || "").toLowerCase();
    if (/embed|tts|audio|realtime|image-gen|imagen|veo|moderation|whisper|transcri|rerank|guard|computer-use/.test(name)) return false;
    if (providerId === "openai") return /gpt-5\.6|gpt-5\.5|gpt-5\.4|gpt-5\.3|gpt-5\.2|gpt-4\.1|gpt-4o/.test(name);
    if (providerId === "gemini") return /gemini-(3|2\.5).*(pro|flash)/.test(name) && !/live|tts|image/.test(name);
    if (providerId === "anthropic") return /claude-(fable|opus|sonnet|haiku)-(5|4)/.test(name);
    if (providerId === "deepseek") return /deepseek-v4-(pro|flash)/.test(name);
    if (providerId === "siliconflow") return /qwen3.*vl|glm-4.*v|kimi-k2|qwen3-(coder|max|plus)|deepseek-v4/.test(name);
    if (providerId === "kimi") return /kimi-k2|moonshot-v1-(32k|128k)/.test(name);
    if (providerId === "minimax") return /minimax-m(3|2\.[5-9])/.test(name);
    if (providerId === "dashscope") return /qwen3.*(vl|coder|max|plus)|qwen-vl-(max|plus)|qwen3\.[5-9]/.test(name);
    if (providerId === "bigmodel") return /glm-(5|4\.[5-9])/.test(name);
    if (providerId === "agnes") return /agnes-2.*flash/.test(name);
    if (providerId === "openrouter") {
      const modalities = raw?.architecture?.input_modalities || [];
      const vision = modalities.includes("image");
      const frontier = /gpt-5|claude-(fable|opus|sonnet)|gemini-(3|2\.5)|deepseek-v4|qwen3.*vl|glm-5/.test(name);
      return vision || frontier;
    }
    return !/embed|rerank|moderation/.test(name);
  }

  function modelHasVision(id, providerId, raw) {
    const name = String(id || "").toLowerCase();
    if (providerId === "deepseek") return false;
    if (providerId === "openrouter") return (raw?.architecture?.input_modalities || []).includes("image");
    if (["openai", "gemini", "anthropic"].includes(providerId)) return true;
    if (providerId === "agnes") return /agnes-2.*flash/.test(name);
    return /vision|vl|glm-4.*v|kimi-k2\.[5-9]|minimax-m3|multimodal/.test(name);
  }

  async function fetchModels(config) {
    if (!config.modelsEndpoint) throw new Error("当前预设没有模型列表地址。");
    let url = config.modelsEndpoint;
    const headers = {};
    if (config.type === "gemini") url += `${url.includes("?") ? "&" : "?"}key=${encodeURIComponent(config.apiKey)}`;
    else if (config.type === "anthropic") {
      headers["x-api-key"] = config.apiKey;
      headers["anthropic-version"] = "2023-06-01";
      headers["anthropic-dangerous-direct-browser-access"] = "true";
    } else if (config.apiKey) headers.Authorization = `Bearer ${config.apiKey}`;
    const data = await withRetries(config, null, async signal => parseResponse(await fetch(url, { headers, signal })));
    let rows = [];
    if (Array.isArray(data.data)) rows = data.data.map(item => ({ id: item.id, name: item.name || item.display_name || item.id, raw: item }));
    else if (Array.isArray(data.models)) rows = data.models.map(item => ({ id: String(item.name || "").replace(/^models\//, ""), name: item.displayName || item.name, raw: item }));
    const filtered = rows
      .filter(item => item.id && isStrongModel(item.id, config.providerId, item.raw))
      .map(item => ({
        id: item.id,
        name: item.name || item.id,
        vision: modelHasVision(item.id, config.providerId, item.raw)
      }))
      .slice(0, 100);
    if (!filtered.length) throw new Error("没有找到符合筛选条件的强力/多模态模型，可改用手动模型 ID。");
    return filtered;
  }

  async function testConnection(config) {
    return generate(config, "Reply with exactly: GARY_OK", "Connection test. Reply with exactly GARY_OK.", []);
  }

  window.GaryApi = { generate, fetchModels, testConnection, GaryApiError };
})();
