(function () {
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const hasChrome = typeof chrome !== "undefined" && chrome.storage?.local;
  const DATA_CONSENT_VERSION = 1;
  const SHARE_URL = "https://dream3d.vip/gary-prompt/";

  const storage = {
    async get(key) {
      if (hasChrome) return (await chrome.storage.local.get(key))[key];
      try { return JSON.parse(localStorage.getItem(key)); } catch (_) { return null; }
    },
    async set(key, value) {
      if (hasChrome) return chrome.storage.local.set({ [key]: value });
      localStorage.setItem(key, JSON.stringify(value));
    }
  };

  const state = {
    selectedSkillId: "s25-general",
    customSkills: [],
    category: "全部",
    search: "",
    mode: "generate",
    files: [],
    history: [],
    result: "",
    resultFormat: "native",
    analysisRows: [],
    analysisMeta: null,
    editingSkillId: null,
    settings: {
      providerId: "siliconflow",
      uiLanguage: "auto",
      language: "简体中文",
      frameCount: 6,
      analysisInterval: 3,
      analysisOutput: "table",
      referenceIntent: "auto",
      retryCount: 2,
      requestTimeout: 240,
      providerConfigs: {}
    }
  };

  const els = {
    workspaceView: $("#workspaceView"), skillView: $("#skillView"), settingsView: $("#settingsView"), historyView: $("#historyView"),
    promptInput: $("#promptInput"), supplementInput: $("#supplementInput"), supplementHint: $("#supplementHint"), primaryPromptBlock: $("#primaryPromptBlock"), quickOptions: $("#quickOptions"), promptLabel: $("#promptLabel"), promptHelp: $("#promptHelp"), charCount: $("#charCount"), durationSelect: $("#durationSelect"), ratioSelect: $("#ratioSelect"),
    selectedSkillIcon: $("#selectedSkillIcon"), selectedSkillName: $("#selectedSkillName"), selectedSkillHint: $("#selectedSkillHint"),
    openSkillLibrary: $("#openSkillLibrary"), skillSearch: $("#skillSearch"), categoryTabs: $("#categoryTabs"), skillGrid: $("#skillGrid"),
    fileInput: $("#fileInput"), uploadButton: $("#uploadButton"), uploadTitle: $("#uploadTitle"), uploadHint: $("#uploadHint"), mediaZone: $("#mediaZone"), mediaList: $("#mediaList"),
    referenceIntentWrap: $("#referenceIntentWrap"), referenceIntentSelect: $("#referenceIntentSelect"),
    generateButton: $("#generateButton"), composerNote: $("#composerNote"), modelStatus: $("#modelStatus"),
    resultCard: $("#resultCard"), resultContent: $("#resultContent"), resultFormatBadge: $("#resultFormatBadge"), copyButton: $("#copyButton"), exportButton: $("#exportButton"), convertH3Button: $("#convertH3Button"), insertButton: $("#insertButton"),
    settingsForm: $("#settingsForm"), providerSelect: $("#providerSelect"), providerHint: $("#providerHint"), endpointInput: $("#endpointInput"),
    apiKeyInput: $("#apiKeyInput"), modelSelect: $("#modelSelect"), customModelInput: $("#customModelInput"), uiLanguageSelect: $("#uiLanguageSelect"), languageSelect: $("#languageSelect"),
    frameCountSelect: $("#frameCountSelect"), refreshModelsButton: $("#refreshModelsButton"), testApiButton: $("#testApiButton"),
    retryCountSelect: $("#retryCountSelect"), requestTimeoutSelect: $("#requestTimeoutSelect"),
    getApiKeyButton: $("#getApiKeyButton"), analysisOptions: $("#analysisOptions"), analysisIntervalSelect: $("#analysisIntervalSelect"), analysisOutputSelect: $("#analysisOutputSelect"),
    historyList: $("#historyList"), customSkillDialog: $("#customSkillDialog"), customSkillForm: $("#customSkillForm"),
    customSkillName: $("#customSkillName"), customSkillCategory: $("#customSkillCategory"), customSkillDescription: $("#customSkillDescription"),
    customSkillPrompt: $("#customSkillPrompt"), privacyConsentDialog: $("#privacyConsentDialog"), toast: $("#toast")
  };

  function allSkills() { return [...window.GARY_SKILLS, ...state.customSkills]; }
  function tr(value) { return window.GaryI18n.text(value); }
  function selectedSkill() { return allSkills().find(skill => skill.id === state.selectedSkillId) || window.GARY_SKILLS[0]; }
  function providerById(id) { return window.GARY_PROVIDERS.find(item => item.id === id) || window.GARY_PROVIDERS[0]; }

  function defaultProviderConfig(provider) {
    return {
      endpoint: provider.endpoint,
      apiKey: "",
      model: provider.models[0]?.id || "",
      customModel: "",
      models: provider.models
    };
  }

  function providerConfig(id) {
    const provider = providerById(id);
    if (!state.settings.providerConfigs[id]) state.settings.providerConfigs[id] = defaultProviderConfig(provider);
    return state.settings.providerConfigs[id];
  }

  function currentApiConfig(fromForm) {
    const provider = providerById(fromForm ? els.providerSelect.value : state.settings.providerId);
    const saved = providerConfig(provider.id);
    const selectedModel = fromForm
      ? (els.modelSelect.value === "__custom__" ? els.customModelInput.value.trim() : els.modelSelect.value)
      : (saved.model === "__custom__" ? saved.customModel : saved.model);
    return {
      providerId: provider.id,
      type: provider.type,
      endpoint: fromForm ? els.endpointInput.value.trim() : saved.endpoint,
      apiKey: fromForm ? els.apiKeyInput.value.trim() : saved.apiKey,
      model: selectedModel,
      modelsEndpoint: provider.modelsEndpoint,
      retryCount: Number(state.settings.retryCount ?? 2),
      timeoutMs: Number(state.settings.requestTimeout || 240) * 1000
    };
  }

  async function ensureDataConsent() {
    if (Number(state.settings.dataConsentVersion || 0) >= DATA_CONSENT_VERSION) return true;
    if (!els.privacyConsentDialog?.showModal) return false;
    return new Promise(resolve => {
      const onClose = async () => {
        const accepted = els.privacyConsentDialog.returnValue === "accept";
        if (accepted) {
          state.settings.dataConsentVersion = DATA_CONSENT_VERSION;
          await storage.set("garySettings", state.settings);
        }
        resolve(accepted);
      };
      els.privacyConsentDialog.addEventListener("close", onClose, { once: true });
      els.privacyConsentDialog.showModal();
    });
  }

  function endpointPermissionPattern(endpoint) {
    let url;
    try { url = new URL(endpoint); }
    catch (_) { throw new Error("API 地址格式不正确。"); }
    const localHttp = url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !localHttp) throw new Error("Edge 商店版只允许 HTTPS API；本机 localhost/127.0.0.1 可以使用 HTTP。");
    return `${url.protocol}//${url.host}/*`;
  }

  async function ensureApiPermissions(endpoints) {
    const origins = [...new Set(endpoints.filter(Boolean).map(endpointPermissionPattern))];
    if (!hasChrome || !chrome.permissions || !origins.length) return true;
    const missing = [];
    for (const origin of origins) {
      if (!(await chrome.permissions.contains({ origins: [origin] }))) missing.push(origin);
    }
    if (!missing.length) return true;
    const granted = await chrome.permissions.request({ origins: missing });
    if (!granted) showToast("未获得 API 域名访问权限，无法发送请求。", true);
    return granted;
  }

  async function prepareApiAccess(config, includeModelsEndpoint) {
    if (!(await ensureDataConsent())) {
      showToast("需要同意数据处理说明后才能调用 API。", true);
      return false;
    }
    try { return await ensureApiPermissions([config.endpoint, includeModelsEndpoint ? config.modelsEndpoint : ""]); }
    catch (error) { showToast(error.message, true); return false; }
  }

  async function shareExtension() {
    const english = window.GaryI18n.getLocale() === "en";
    const shareData = {
      title: "Gary Prompt",
      text: english
        ? "Gary Prompt turns ideas, images, and sampled video frames into production-ready AI video prompts."
        : "Gary Prompt：把创意、图片和视频解析成可直接生成的 AI 视频提示词。",
      url: SHARE_URL
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        showToast("已打开系统分享面板");
        return;
      }
    } catch (error) {
      if (error?.name === "AbortError") return;
    }
    const shareText = `${shareData.text}\n${shareData.url}`;
    try { await navigator.clipboard.writeText(shareText); }
    catch (_) {
      const area = document.createElement("textarea"); area.value = shareText; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove();
    }
    showToast("分享文案和安装链接已复制");
  }

  function modelSupportsVision() {
    const config = currentApiConfig(false);
    const saved = providerConfig(config.providerId);
    const model = (saved.models || []).find(item => item.id === config.model);
    if (config.providerId === "deepseek") return false;
    return model ? model.vision !== false : true;
  }

  function showToast(message, error) {
    els.toast.textContent = tr(message);
    els.toast.classList.toggle("error", Boolean(error));
    els.toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2600);
  }

  function setLoading(show, title, text) {
    window.GaryJobs.setTransient(show, title || "正在处理", text || "请稍候…");
  }

  function showView(view) {
    [els.workspaceView, els.skillView, els.settingsView, els.historyView].forEach(item => item.classList.add("hidden"));
    view.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderSelectedSkill() {
    const skill = selectedSkill();
    els.selectedSkillIcon.textContent = skill.icon || "SK";
    els.selectedSkillName.textContent = `${skill.model ? skill.model + " · " : ""}${tr(skill.title)}`;
    els.selectedSkillHint.textContent = `${skill.source ? tr(skill.source) + " · " : ""}${skill.engine === "h3" ? `${tr("自动套用官方 H3 模板")} · ` : ""}${tr(skill.short || skill.description)}`;
  }

  function renderStatus() {
    const config = currentApiConfig(false);
    const ready = Boolean(config.apiKey && config.model && config.endpoint);
    els.modelStatus.classList.toggle("ready", ready);
    els.modelStatus.querySelector("span").textContent = ready ? `${providerById(config.providerId).name} · ${config.model}` : tr("未配置 API");
    els.composerNote.textContent = ready
      ? (window.GaryI18n.getLocale() === "en" ? `Using ${config.model}; media is preprocessed locally.` : `将使用 ${config.model}；素材先在浏览器本地预处理。`)
      : tr("请先在右上角设置中配置 API、模型与输出语言。");
  }

  function renderMode() {
    const analyzing = state.mode === "analyze";
    const reversing = state.mode === "reverse";
    els.analysisOptions.classList.toggle("hidden", !analyzing);
    els.openSkillLibrary.classList.toggle("hidden", reversing);
    els.primaryPromptBlock.classList.toggle("hidden", reversing);
    els.quickOptions.classList.toggle("hidden", reversing);
    els.fileInput.accept = analyzing ? "video/*" : reversing ? "image/*" : "image/*,video/*";
    els.fileInput.multiple = !reversing;
    els.promptLabel.textContent = tr(analyzing ? "分析重点（可选）" : "描述你的画面或任务");
    els.promptInput.placeholder = tr(analyzing
      ? "例如：重点分析人物动作、镜头变化和产品出现的时间……"
      : "例如：雨夜的东京街头，一位红衣女孩撑伞回头，镜头缓慢环绕，想做 15 秒电影感短片……");
    els.promptHelp.textContent = tr(analyzing ? "不填写时执行完整镜头分析；视频音频仍需要单独转写。" : "");
    els.promptHelp.classList.toggle("hidden", !analyzing);
    els.supplementInput.placeholder = tr(reversing
      ? "例如：重点还原服装材质、摄影光线和画面文字；使用专业摄影术语……"
      : "例如：加入人物台词“欢迎来到 Gary Prompt”，在第 5 秒说出；保持人物服装不变；不要添加背景音乐……");
    els.supplementHint.textContent = tr(reversing
      ? "仅用于指定反推重点、专业术语或输出偏好；如需新增台词、动作或改写画面，请使用“生成提示词”。"
      : "补充内容会与主任务一起发送，并作为必须执行的要求合并到最终结果。");
    els.uploadTitle.textContent = tr(analyzing ? "上传需要解析的视频" : reversing ? "上传需要反推的图片" : "上传图片或视频");
    els.uploadHint.textContent = tr(analyzing ? "支持多个视频 · 自动依次排队" : reversing ? "上传 1 张图片 · 输出 1 份专业图像提示词" : "图像参考 · 视频抽帧 · 最多 8 个文件");
    els.generateButton.querySelector("span").textContent = tr(analyzing ? "加入视频解析队列" : reversing ? "加入图像反推队列" : "加入生成队列");
    els.composerNote.textContent = reversing
      ? tr("图像反推不使用当前 Skill，也不会生成视频动作、台词或时间轴。")
      : analyzing
      ? tr("视频只在浏览器本地解码和均匀抽帧；抽出的帧会提交给你配置的多模态 API。")
      : (currentApiConfig(false).apiKey ? (window.GaryI18n.getLocale() === "en" ? `Using ${currentApiConfig(false).model}; media is preprocessed locally.` : `将使用 ${currentApiConfig(false).model}；素材先在浏览器本地预处理。`) : tr("请先在右上角设置中配置 API、模型与输出语言。"));
    renderReferenceIntent();
  }

  function referenceIntentLabel(value) {
    return ({
      auto: "智能判断：按用户描述判断素材是首帧还是一般参考；不按图片数量武断决定",
      "first-frame": "首帧图生视频：第 1 张图片是目标视频 0.00 秒的真实首帧",
      "first-last": "首尾帧过渡：第 1 张是首帧，第 2 张是尾帧",
      "last-frame": "尾帧反推视频：第 1 张图片是目标视频的真实尾帧",
      "asset-reference": "全能参考：图片/视频仅用于角色、产品、场景、风格、动作或运镜参考，不强制成为首尾帧"
    })[value] || "智能判断";
  }

  function renderReferenceIntent() {
    const hasMedia = state.files.length > 0;
    els.referenceIntentWrap.classList.toggle("hidden", !hasMedia || state.mode !== "generate");
  }

  function renderCategories() {
    const categories = ["全部", "Seedance 2.0", "Seedance 2.5", "MiniMax H3"];
    if (state.customSkills.length) categories.push("自定义");
    els.categoryTabs.innerHTML = "";
    categories.forEach(category => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `category-tab${state.category === category ? " active" : ""}`;
      button.textContent = tr(category);
      button.addEventListener("click", () => { state.category = category; renderCategories(); renderSkillGrid(); });
      els.categoryTabs.appendChild(button);
    });
  }

  function renderSkillGrid() {
    const query = state.search.toLowerCase();
    const list = allSkills().filter(skill => {
      const categoryMatch = state.category === "全部" || skill.category === state.category;
      const haystack = [skill.title, tr(skill.title), skill.model, skill.source, skill.useCase, tr(skill.useCase), skill.short, tr(skill.short), skill.description, tr(skill.description), ...(skill.tags || [])].join(" ").toLowerCase();
      return categoryMatch && (!query || haystack.includes(query));
    });
    els.skillGrid.innerHTML = "";
    if (!list.length) {
      els.skillGrid.innerHTML = `<div class="empty-state">${escapeHtml(tr("没有找到匹配的 Skill。"))}<br>${escapeHtml(tr("可以换个关键词，或添加自己的 Skill。"))}</div>`;
      return;
    }
    list.forEach(skill => {
      const card = document.createElement("article");
      card.className = `skill-card${skill.id === state.selectedSkillId ? " selected" : ""}`;
      card.tabIndex = 0;
      const isCustom = skill.custom === true;
      card.innerHTML = `
        <div class="skill-icon">${escapeHtml(skill.icon || "SK")}</div>
        <div class="skill-card-copy">
          <div class="skill-card-title"><strong>${escapeHtml(tr(skill.title))}</strong><span>${escapeHtml(skill.model || tr(skill.category))}</span>${skill.source ? `<span class="source-badge">${escapeHtml(tr(skill.source))}</span>` : ""}</div>
          <p>${escapeHtml(tr(skill.short || skill.description))}</p>
          <div class="skill-card-meta">${skill.useCase ? `<span>${escapeHtml(tr("用途"))}: ${escapeHtml(tr(skill.useCase))}</span>` : ""}<span>${escapeHtml(tr("需要"))}: ${escapeHtml(tr(skill.needs || "文字描述"))}</span><span>${escapeHtml(tr("产出"))}: ${escapeHtml(tr(skill.output || "成品提示词"))}</span></div>
        </div>
        <svg class="chevron" viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></svg>
        ${isCustom ? `<div class="skill-card-actions"><button type="button" data-edit>${escapeHtml(tr("编辑"))}</button><button type="button" data-delete>${escapeHtml(tr("删除"))}</button></div>` : ""}`;
      const choose = () => {
        state.selectedSkillId = skill.id;
        storage.set("garySelectedSkill", skill.id);
        renderSelectedSkill();
        showView(els.workspaceView);
        showToast(`${tr("已选择")}：${tr(skill.title)}`);
      };
      card.addEventListener("click", event => { if (!event.target.closest(".skill-card-actions")) choose(); });
      card.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); choose(); } });
      if (isCustom) {
        card.querySelector("[data-edit]").addEventListener("click", () => openCustomSkillDialog(skill));
        card.querySelector("[data-delete]").addEventListener("click", async () => {
          if (!confirm(`删除自定义 Skill“${skill.title}”？`)) return;
          state.customSkills = state.customSkills.filter(item => item.id !== skill.id);
          if (state.selectedSkillId === skill.id) state.selectedSkillId = "s25-general";
          await storage.set("garyCustomSkills", state.customSkills);
          await storage.set("garySelectedSkill", state.selectedSkillId);
          renderCategories(); renderSkillGrid(); renderSelectedSkill();
        });
      }
      els.skillGrid.appendChild(card);
    });
  }

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
  }

  function openCustomSkillDialog(skill) {
    state.editingSkillId = skill?.id || null;
    els.customSkillName.value = skill?.title || "";
    const category = skill?.displayCategory || skill?.category || "自定义";
    els.customSkillCategory.value = category === "自定义" ? tr(category) : category;
    els.customSkillDescription.value = skill?.description || "";
    els.customSkillPrompt.value = skill?.prompt || "";
    els.customSkillDialog.showModal();
  }

  function renderProviderOptions() {
    els.providerSelect.innerHTML = "";
    const featured = document.createElement("optgroup");
    featured.label = tr("常用预设");
    const others = document.createElement("optgroup");
    others.label = tr("其他服务");
    window.GARY_PROVIDERS.forEach(provider => {
      const option = document.createElement("option");
      option.value = provider.id;
      option.textContent = `${provider.featured ? "★ " : ""}${provider.name}`;
      (provider.featured ? featured : others).appendChild(option);
    });
    if (featured.children.length) els.providerSelect.appendChild(featured);
    if (others.children.length) els.providerSelect.appendChild(others);
  }

  function saveFormToProviderConfig(providerId) {
    if (!providerId) return;
    const config = providerConfig(providerId);
    config.endpoint = els.endpointInput.value.trim();
    config.apiKey = els.apiKeyInput.value.trim();
    config.model = els.modelSelect.value;
    config.customModel = els.customModelInput.value.trim();
  }

  function loadProviderForm(providerId) {
    const provider = providerById(providerId);
    const config = providerConfig(providerId);
    els.providerSelect.value = providerId;
    els.providerHint.textContent = tr(provider.hint);
    if (provider.signupUrl) {
      els.getApiKeyButton.href = provider.signupUrl;
      els.getApiKeyButton.classList.remove("hidden");
      els.getApiKeyButton.setAttribute("aria-label", `获取 ${provider.name} API Key`);
    } else {
      els.getApiKeyButton.removeAttribute("href");
      els.getApiKeyButton.classList.add("hidden");
    }
    els.endpointInput.value = config.endpoint;
    els.apiKeyInput.value = config.apiKey;
    renderModelOptions(providerId);
  }

  function renderModelOptions(providerId) {
    const config = providerConfig(providerId);
    const models = config.models?.length ? config.models : providerById(providerId).models;
    els.modelSelect.innerHTML = "";
    models.forEach(model => {
      const option = document.createElement("option");
      option.value = model.id;
      option.textContent = model.name || model.id;
      els.modelSelect.appendChild(option);
    });
    if (!models.some(item => item.id === "__custom__")) {
      const option = document.createElement("option");
      option.value = "__custom__";
      option.textContent = tr("手动输入模型 ID…");
      els.modelSelect.appendChild(option);
    }
    els.modelSelect.value = models.some(item => item.id === config.model) || config.model === "__custom__" ? config.model : models[0]?.id || "__custom__";
    config.model = els.modelSelect.value;
    els.customModelInput.value = config.customModel || "";
    els.customModelInput.classList.toggle("hidden", els.modelSelect.value !== "__custom__");
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  async function readFileDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error(`无法读取 ${file.name}`));
      reader.readAsDataURL(file);
    });
  }

  async function imageFromUrl(url) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("图片解码失败"));
      image.src = url;
    });
  }

  function canvasDataUrl(source, maxWidth, maxHeight, quality) {
    const ratio = Math.min(1, maxWidth / source.videoWidth || maxWidth / source.naturalWidth, maxHeight / source.videoHeight || maxHeight / source.naturalHeight);
    const sourceWidth = source.videoWidth || source.naturalWidth;
    const sourceHeight = source.videoHeight || source.naturalHeight;
    const width = Math.max(1, Math.round(sourceWidth * ratio));
    const height = Math.max(1, Math.round(sourceHeight * ratio));
    const canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext("2d", { alpha: false });
    ctx.fillStyle = "#111"; ctx.fillRect(0, 0, width, height); ctx.drawImage(source, 0, 0, width, height);
    return canvas.toDataURL("image/jpeg", quality || .84);
  }

  async function compressImage(file) {
    const raw = await readFileDataUrl(file);
    const image = await imageFromUrl(raw);
    return canvasDataUrl(image, 1600, 1600, .86);
  }

  async function loadVideo(file) {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    const url = URL.createObjectURL(file);
    video.src = url;
    await new Promise((resolve, reject) => {
      video.onloadedmetadata = resolve;
      video.onerror = () => reject(new Error(`无法解析视频 ${file.name}`));
    });
    return { video, url };
  }

  async function seekVideo(video, time) {
    if (Math.abs(video.currentTime - time) < .03 && video.readyState >= 2) return;
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("视频抽帧超时")), 12000);
      video.onseeked = () => { clearTimeout(timeout); resolve(); };
      video.onerror = () => { clearTimeout(timeout); reject(new Error("视频帧读取失败")); };
      video.currentTime = Math.max(0, Math.min(time, Math.max(0, video.duration - .04)));
    });
  }

  async function videoThumbnail(file) {
    const loaded = await loadVideo(file);
    try {
      await seekVideo(loaded.video, Math.min(.15, loaded.video.duration * .05));
      return { dataUrl: canvasDataUrl(loaded.video, 480, 320, .72), duration: loaded.video.duration };
    } finally { URL.revokeObjectURL(loaded.url); }
  }

  async function extractVideoFramesAtTimes(file, times, onFrame) {
    const loaded = await loadVideo(file);
    const frames = [];
    try {
      for (let index = 0; index < times.length; index++) {
        const time = times[index];
        await seekVideo(loaded.video, time);
        frames.push({ dataUrl: canvasDataUrl(loaded.video, 1280, 1280, .82), time, frameIndex: index + 1 });
        onFrame?.(index + 1, times.length);
      }
    } finally { URL.revokeObjectURL(loaded.url); }
    return frames;
  }

  async function extractVideoFrames(file, count, knownDuration, onFrame) {
    const duration = Number(knownDuration) || 1;
    const segment = duration / Math.max(1, count);
    const times = Array.from({ length: count }, (_, index) => Math.min(duration - .04, (index * segment) + (segment / 2)));
    return extractVideoFramesAtTimes(file, times, onFrame);
  }

  function uniformIntervalTimes(duration, interval) {
    const count = Math.max(1, Math.ceil(duration / interval));
    if (count > 60) throw new Error(`当前间隔会抽取 ${count} 帧，单段视频最多 60 帧。请增大均匀时间间隔。`);
    return Array.from({ length: count }, (_, index) => {
      const start = index * interval;
      const end = Math.min(duration, start + interval);
      return Math.min(duration - .04, start + Math.max(.02, (end - start) / 2));
    });
  }

  async function addFiles(fileList) {
    const accepted = Array.from(fileList).filter(file => state.mode === "reverse" ? file.type.startsWith("image/") : file.type.startsWith("image/") || file.type.startsWith("video/"));
    if (!accepted.length) return showToast(state.mode === "reverse" ? "请选择图片文件。" : "请选择图片或视频文件。", true);
    const limit = state.mode === "reverse" ? 1 : 8;
    const slots = Math.max(0, limit - state.files.length);
    if (!slots) return showToast(state.mode === "reverse" ? "图像反推每次只处理一张图片。" : "最多上传 8 个文件。", true);
    setLoading(true, "正在读取素材", "生成本地预览，不会上传到其他地方。 ");
    try {
      for (const file of accepted.slice(0, slots)) {
        if (file.size > 500 * 1024 * 1024) { showToast(`${file.name} 超过 500MB，已跳过。`, true); continue; }
        const kind = file.type.startsWith("video/") ? "video" : "image";
        let thumb, duration = null;
        if (kind === "image") thumb = await compressImage(file);
        else {
          const preview = await videoThumbnail(file);
          thumb = preview.dataUrl; duration = preview.duration;
        }
        state.files.push({ id: `${Date.now()}-${Math.random()}`, file, kind, thumb, duration });
      }
      renderMedia();
    } catch (error) { showToast(error.message, true); }
    finally { setLoading(false); els.fileInput.value = ""; }
  }

  function renderMedia() {
    els.mediaList.innerHTML = "";
    state.files.forEach(item => {
      const row = document.createElement("div");
      row.className = "media-item";
      const typeLabel = item.kind === "video"
        ? (window.GaryI18n.getLocale() === "en" ? `Video · ${item.duration?.toFixed(1) || "?"}s` : `视频 · ${item.duration?.toFixed(1) || "?"} 秒`)
        : tr("图片");
      row.innerHTML = `<img class="media-thumb" src="${item.thumb}" alt=""><div class="media-meta"><strong>${escapeHtml(item.file.name)}</strong><span>${escapeHtml(typeLabel)} · ${formatBytes(item.file.size)}</span></div><button class="media-remove" type="button" aria-label="${escapeHtml(tr("移除"))}">×</button>`;
      row.querySelector("button").addEventListener("click", () => { state.files = state.files.filter(file => file.id !== item.id); renderMedia(); });
      els.mediaList.appendChild(row);
    });
    renderReferenceIntent();
  }

  async function prepareMedia(files = state.files, frameCount = Number(state.settings.frameCount || 6), onProgress) {
    const media = [];
    const mapping = [];
    let imageNumber = 0, videoNumber = 0, inputNumber = 0;
    const totalUnits = files.reduce((sum, item) => sum + (item.kind === "video" ? frameCount : 1), 0) || 1;
    let completedUnits = 0;
    for (const item of files) {
      if (item.kind === "image") {
        imageNumber += 1; inputNumber += 1;
        media.push({ dataUrl: item.thumb, name: item.file.name });
        mapping.push(`输入图像 ${inputNumber} = @图片${imageNumber}（文件：${item.file.name}）`);
        completedUnits += 1;
        onProgress?.(completedUnits / totalUnits);
      } else {
        videoNumber += 1;
        const baseUnits = completedUnits;
        const frames = await extractVideoFrames(item.file, frameCount, item.duration, current => onProgress?.((baseUnits + current) / totalUnits));
        completedUnits += frameCount;
        mapping.push(`@视频${videoNumber}（文件：${item.file.name}，时长 ${item.duration?.toFixed(2) || "未知"} 秒）已在本地均匀抽取 ${frames.length} 帧：`);
        frames.forEach(frame => {
          inputNumber += 1;
          media.push({ dataUrl: frame.dataUrl, name: `${item.file.name} @ ${frame.time.toFixed(2)}s` });
          mapping.push(`输入图像 ${inputNumber} = @视频${videoNumber} 的 ${frame.time.toFixed(2)} 秒关键帧`);
        });
      }
    }
    return { media, mapping: mapping.join("\n") };
  }

  function buildUserRequest(mapping, snapshot) {
    const modeMap = {
      generate: "生成一份可直接用于目标视频模型的成品提示词。",
      analyze: "先对上传素材进行结构化解析（主体、场景、镜头、动作、光影、声音、节奏、一致性风险），再给出适配当前 Skill 的创作建议；不要假装听到了仅靠抽帧无法判断的声音。",
      reverse: "以上传图片为唯一画面事实来源，忠实反推出可复现主体、构图、场景、服装、道具、光影、色彩、文字与原始风格的成品视频提示词。静态图片中看不到的动作、运镜和声音只能按用户补充设计，或采用最小且自然的合理设计；不得擅自改成所选 Skill 的主题风格。直接观察与合理推断必须在内部区分和校验，不得作为分析章节输出。"
    };
    const outputContract = snapshot.mode === "reverse"
      ? `只输出一个最终版本，用户不需要自行挑选或删除内容。禁止输出分析过程、推理过程、创作说明、方案比较、候选版本。不要输出“视觉隐喻方案”“直接观察与合理推断”“镜头时间轴”“H3 提示词”等包装标题；如果目标是 H3，正文必须直接从对应的官方首字段或图片对齐句开始。`
      : "只输出一个完整的最终成品版本，不要附带推理过程、草稿或候选版本。";
    return `<task>
${modeMap[snapshot.mode]}
</task>

<user_idea>
${snapshot.prompt || (snapshot.mode === "reverse" ? "无额外反推重点，请忠实覆盖图片中的全部关键视觉信息。" : "用户未补充文字，请以上传素材为主要依据。")}
</user_idea>

<user_supplement priority="must_follow">
${snapshot.supplement || "无额外补充要求。"}
</user_supplement>

<production_settings>
目标模型/Skill：${snapshot.skill.model || snapshot.skill.category} · ${snapshot.skill.title}
目标时长：${snapshot.duration}
画幅比例：${snapshot.ratio}
输出语言：${snapshot.settings.language}
参考素材用途：${referenceIntentLabel(snapshot.settings.referenceIntent)}
</production_settings>

${mapping ? `<uploaded_media_mapping>\n${mapping}\n请把视频关键帧按同一段视频的时间序列理解，不要把同一角色的不同帧误当成不同角色。\n</uploaded_media_mapping>` : "<uploaded_media_mapping>无上传素材</uploaded_media_mapping>"}

<delivery>
用 ${snapshot.settings.language} 输出。即使当前 Skill 原本偏向文生视频，只要上传了参考素材，也必须根据“参考素材用途”将成品改写成相应的图生视频、首尾帧、尾帧或全参考提示词。不要把普通角色图/产品图错误声明成真实首帧。主提示词必须完整、连续、可复制；如果当前 Skill 规定 H3 字段名使用英文，字段名保持英文。
<user_supplement> 是全局高优先级要求，必须自然合并进最终成品，不得遗漏、弱化或仅作为建议另列。若补充包含人物台词，必须在最终提示词中写明说话者、台词原文、出现时机、表演情绪和口型同步；若与平台固定格式冲突，在不破坏格式的前提下完整表达其语义。
${outputContract}
</delivery>`;
  }

  function renderResult() {
    const h3 = state.resultFormat === "h3";
    const imageReverse = state.resultFormat === "image-reverse";
    els.resultFormatBadge.textContent = state.resultFormat === "analysis" ? tr("视频解析") : imageReverse ? tr("图像提示词") : h3 ? "MiniMax H3" : tr("原 Skill 格式");
    els.resultFormatBadge.classList.toggle("h3", h3);
    els.convertH3Button.disabled = h3 || state.resultFormat === "analysis" || imageReverse;
    els.convertH3Button.textContent = tr(h3 ? "已是 H3 格式" : state.resultFormat === "analysis" ? "解析结果不可转换" : imageReverse ? "图像反推结果不可转换" : "转为 H3 格式");
    els.resultContent.classList.toggle("table-result", Boolean(state.analysisRows.length && state.analysisMeta?.output === "table"));
    if (!state.analysisRows.length || state.analysisMeta?.output !== "table") {
      els.resultContent.textContent = state.result;
      return;
    }
    const columns = [
      [tr("时间"), row => `${Number(row.timestamp).toFixed(2)}s`],
      [tr("景别"), row => row.shotType],
      [tr("主体/动作"), row => `${row.subject}；${row.action}`],
      [tr("场景"), row => row.scene],
      [tr("运镜判断"), row => row.cameraMovement],
      [tr("风格"), row => row.style],
      [tr("画面描述"), row => row.description]
    ];
    const head = columns.map(column => `<th>${column[0]}</th>`).join("");
    const body = state.analysisRows.map(row => `<tr>${columns.map(column => `<td>${escapeHtml(column[1](row))}</td>`).join("")}</tr>`).join("");
    const summary = window.GaryI18n.getLocale() === "en" ? `${state.analysisMeta.duration.toFixed(2)}s · every ${state.analysisMeta.interval}s · ${state.analysisRows.length} frames` : `${state.analysisMeta.duration.toFixed(2)} 秒 · 每 ${state.analysisMeta.interval} 秒 · ${state.analysisRows.length} 帧`;
    els.resultContent.innerHTML = `<div class="analysis-summary"><strong>${escapeHtml(state.analysisMeta.videoName)}</strong><span>${summary}</span></div><div class="analysis-table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div><p class="analysis-disclaimer">${escapeHtml(tr("静态帧不能确认真实运镜；对白与音效未分析，需要音频转写。"))}</p>`;
  }

  function retryProgress(update, progress) {
    return {
      onRetry(info) {
        const wait = Math.max(1, Math.round(info.delayMs / 1000));
        if (window.GaryI18n.getLocale() === "en") {
          update(progress, `Temporary API issue · preparing request ${info.nextAttempt}`, `${info.message} · retrying in ${wait}s`);
        } else {
          update(progress, `API 临时异常 · 准备第 ${info.nextAttempt} 次请求`, `${info.message} · ${wait} 秒后重试`);
        }
      }
    };
  }

  async function analyzeVideo(config, snapshot, update) {
    const video = snapshot.files[0];
    const interval = Number(snapshot.settings.analysisInterval || 3);
    const output = snapshot.settings.analysisOutput || "table";
    const times = uniformIntervalTimes(video.duration || 1, interval);
    update(4, "正在均匀抽帧", `${video.file.name} · ${times.length} 帧 · 每 ${interval} 秒`);
    const frames = await extractVideoFramesAtTimes(video.file, times, current => update(4 + (current / times.length) * 21, `正在抽取第 ${current}/${times.length} 帧`, video.file.name));
    const rows = [];
    const batchSize = 6;
    const batchCount = Math.ceil(frames.length / batchSize);
    for (let offset = 0; offset < frames.length; offset += batchSize) {
      const batch = frames.slice(offset, offset + batchSize).map((frame, index) => ({ ...frame, frameIndex: offset + index + 1 }));
      const batchIndex = Math.floor(offset / batchSize);
      update(27 + (batchIndex / batchCount) * 65, `正在解析第 ${offset + 1}–${offset + batch.length} 帧`, `${providerById(config.providerId).name} · ${config.model}`);
      const analysisFocus = [snapshot.prompt, snapshot.supplement].filter(Boolean).join("；");
      const prompt = window.GaryVideoAnalysis.buildBatchPrompt(video.file.name, batch, analysisFocus, snapshot.settings.language);
      const media = batch.map(frame => ({ dataUrl: frame.dataUrl, name: `${video.file.name} @ ${frame.time.toFixed(2)}s` }));
      const raw = await window.GaryApi.generate(config, window.GaryVideoAnalysis.SYSTEM_PROMPT, prompt, media, retryProgress(update, 27 + (batchIndex / batchCount) * 65));
      rows.push(...window.GaryVideoAnalysis.parseBatch(raw, batch, video.file.name));
      update(27 + ((batchIndex + 1) / batchCount) * 65, `已完成 ${Math.min(offset + batch.length, frames.length)}/${frames.length} 帧`, video.file.name);
    }
    const meta = { videoName: video.file.name, duration: video.duration || 0, interval, output };
    const result = output === "document"
      ? window.GaryVideoAnalysis.markdownDocument(rows, meta)
      : window.GaryVideoAnalysis.markdownTable(rows, meta);
    update(98, "正在整理解析结果", output === "document" ? "生成 Markdown 文档" : "生成镜头表格");
    return { result, analysisRows: rows, analysisMeta: meta, resultFormat: "analysis" };
  }

  async function reverseImage(config, snapshot, update) {
    update(8, "正在读取图片细节", snapshot.files[0].file.name);
    const prepared = await prepareMedia(snapshot.files, 1, fraction => update(8 + fraction * 20, "正在读取图片细节", `${Math.round(fraction * 100)}%`));
    update(32, "正在专业反推图像", `${providerById(config.providerId).name} · ${config.model}`);
    const systemPrompt = `你是专业的静态图像提示词反推专家。你的唯一任务是忠实观察输入图片，并写出一份可用于主流图像生成模型复现该图片的专业提示词。

只描述图片中可以直接观察或高可信判断的内容：主体数量与外观、面部和姿态、服装与材质、道具、环境、前中后景、构图、视角、景别、镜头/摄影特征、光线、色彩、可见文字、媒介与视觉风格。准确保留专有名词和可见文字。

这是图像反推，不是视频创作：禁止加入时间轴、镜头运动、人物台词、口型、动作过程、音效、音乐、视频时长、H3 字段或任何当前 Skill 的创意风格。不得添加图片里不存在的人物、物体、剧情或风格改造。

<user_supplement> 只用于指定反推关注重点、专业术语、详略程度或输出偏好；其中要求新增、删除或改变画面内容的部分不执行。不要解释冲突，也不要给修改版。

只输出一份连续、可直接复制的图像生成提示词。不得输出观察记录、推理过程、分项分析、标题、Markdown、负面提示词、多个版本或说明文字。`;
    const userPrompt = `<image_mapping>\n${prepared.mapping}\n</image_mapping>
<user_supplement>${snapshot.supplement || "无补充要求，请完整忠实反推。"}</user_supplement>
<output_language>${snapshot.settings.language}</output_language>
请只返回一份最终图像提示词。`;
    const rawResult = await window.GaryApi.generate(config, systemPrompt, userPrompt, prepared.media, retryProgress(update, 32));
    const result = window.GaryOutput.cleanImagePrompt(rawResult);
    update(98, "正在整理图像提示词", "移除分析说明，只保留最终提示词");
    return { result, analysisRows: [], analysisMeta: null, resultFormat: "image-reverse" };
  }

  function validateReferenceIntent(snapshot) {
    if (snapshot.mode === "analyze" || !snapshot.files.length) return;
    const imageCount = snapshot.files.filter(item => item.kind === "image").length;
    if (["first-frame", "last-frame"].includes(snapshot.settings.referenceIntent) && imageCount < 1) {
      throw new Error("当前参考用途至少需要上传 1 张图片。");
    }
    if (snapshot.settings.referenceIntent === "first-last" && imageCount < 2) {
      throw new Error("首尾帧过渡需要至少 2 张图片，并按首帧、尾帧顺序上传。");
    }
  }

  function captureSnapshot(config, files) {
    const skill = selectedSkill();
    return {
      config: { ...config },
      files: [...(files || state.files)],
      skill: { ...skill, tags: [...(skill.tags || [])] },
      skillId: state.selectedSkillId,
      mode: state.mode,
      prompt: els.promptInput.value.trim(),
      supplement: els.supplementInput.value.trim(),
      duration: els.durationSelect.value,
      ratio: els.ratioSelect.value,
      settings: {
        language: state.settings.language,
        frameCount: Number(state.settings.frameCount || 6),
        analysisInterval: Number(els.analysisIntervalSelect.value || state.settings.analysisInterval || 3),
        analysisOutput: els.analysisOutputSelect.value || state.settings.analysisOutput || "table",
        referenceIntent: state.mode === "reverse" ? "asset-reference" : (els.referenceIntentSelect.value || state.settings.referenceIntent || "auto"),
        retryCount: Number(state.settings.retryCount ?? 2),
        requestTimeout: Number(state.settings.requestTimeout || 240)
      }
    };
  }

  async function executeGeneration(snapshot, update) {
    validateReferenceIntent(snapshot);
    if (snapshot.mode === "analyze") return analyzeVideo(snapshot.config, snapshot, update);
    if (snapshot.mode === "reverse") return reverseImage(snapshot.config, snapshot, update);
    update(3, snapshot.files.length ? "正在预处理参考素材" : "正在整理创作要求", snapshot.skill.title);
    const prepared = await prepareMedia(snapshot.files, snapshot.settings.frameCount, fraction => update(3 + fraction * 28, "正在预处理参考素材", `${Math.round(fraction * 100)}%`));
    update(34, "正在调用大模型", `${providerById(snapshot.config.providerId).name} · ${snapshot.config.model}`);
      const skill = snapshot.skill;
      const conversionLayer = skill.engine === "h3"
        ? `\n\n<h3_official_conversion_layer>\n${window.GARY_H3_CONVERTER}\n</h3_official_conversion_layer>\n\n先执行 <selected_skill> 的创作规则，再执行 <h3_official_conversion_layer> 的格式转换。两层规则缺一不可。`
        : "";
      const referenceLayer = snapshot.files.length
        ? `\n\n<reference_adaptation>\n当前任务包含参考素材。即使 selected_skill 原本是文生视频工作流，也必须保留它的创作方法，并把最终提示词改写成与以下素材用途相符的生成方式：${referenceIntentLabel(snapshot.settings.referenceIntent)}。先观察素材，再区分“画面中可直接确认的事实”和“用户要求生成的变化”。普通角色、产品或风格参考不得伪装成真实首帧；真实首帧、首尾帧和尾帧则必须严格锁定其时间语义。\n</reference_adaptation>`
        : "";
      const systemPrompt = `${window.GARY_BASE_SYSTEM}\n\n<selected_skill>\n${skill.prompt}\n</selected_skill>${referenceLayer}${conversionLayer}`;
      const userRequest = buildUserRequest(prepared.mapping, snapshot);
      const rawResult = await window.GaryApi.generate(snapshot.config, systemPrompt, userRequest, prepared.media, retryProgress(update, 34));
      const result = skill.engine === "h3" ? window.GaryOutput.cleanH3(rawResult) : rawResult.trim();
      update(97, "正在整理最终提示词", skill.engine === "h3" ? "应用 MiniMax H3 官方结构" : "检查格式与素材映射");
      return { result, analysisRows: [], analysisMeta: null, resultFormat: skill.engine === "h3" ? "h3" : "native" };
  }

  async function acceptCompletedResult(snapshot, payload) {
      state.result = payload.result;
      state.resultFormat = payload.resultFormat;
      state.analysisRows = payload.analysisRows || [];
      state.analysisMeta = payload.analysisMeta || null;
      renderResult();
      els.resultCard.classList.remove("hidden");
      const record = {
        id: `${Date.now()}`,
        createdAt: new Date().toISOString(),
        skillId: snapshot.mode === "reverse" ? "image-reverse" : snapshot.skillId,
        skillTitle: snapshot.mode === "reverse" ? "专业图像反推" : snapshot.skill.title,
        prompt: snapshot.prompt,
        supplement: snapshot.supplement,
        result: payload.result,
        mode: snapshot.mode,
        analysisRows: payload.analysisRows || [],
        analysisMeta: payload.analysisMeta || null,
        resultFormat: payload.resultFormat
      };
      state.history.unshift(record);
      state.history = state.history.slice(0, 20);
      await storage.set("garyHistory", state.history);
      showToast(`${snapshot.mode === "analyze" ? "视频解析" : snapshot.mode === "reverse" ? "图像反推" : "提示词生成"}已完成`);
  }

  function estimateSnapshotMs(snapshot) {
    if (snapshot.mode === "analyze") {
      const frames = Math.ceil((snapshot.files[0]?.duration || 1) / snapshot.settings.analysisInterval);
      return 12000 + (frames * 900) + (Math.ceil(frames / 6) * 38000);
    }
    const videoFrames = snapshot.files.filter(item => item.kind === "video").length * snapshot.settings.frameCount;
    return 42000 + (videoFrames * 900) + (snapshot.files.length * 1200);
  }

  function enqueueSnapshot(snapshot) {
    const modeName = snapshot.mode === "analyze" ? "解析视频" : snapshot.mode === "reverse" ? "图像反推" : "生成提示词";
    const timingVariant = snapshot.mode === "analyze"
      ? `batches-${Math.ceil(Math.ceil((snapshot.files[0]?.duration || 1) / snapshot.settings.analysisInterval) / 6)}`
      : snapshot.files.length ? "with-media" : "text-only";
    return window.GaryJobs.enqueue({
      type: snapshot.mode,
      timingKey: `${snapshot.mode}:${snapshot.config.providerId}:${snapshot.config.model}:${timingVariant}`,
      estimateMs: estimateSnapshotMs(snapshot),
      title: modeName,
      label: `${modeName} · ${["analyze", "reverse"].includes(snapshot.mode) ? snapshot.files[0].file.name : snapshot.skill.title}`,
      labelParts: [modeName, ["analyze", "reverse"].includes(snapshot.mode) ? snapshot.files[0].file.name : snapshot.skill.title],
      detail: `${providerById(snapshot.config.providerId).name} · ${snapshot.config.model}`,
      run: update => executeGeneration(snapshot, update),
      onSuccess: payload => acceptCompletedResult(snapshot, payload),
      onError: error => showToast(`${modeName}失败：${error.message || error}`, true)
    });
  }

  async function generate() {
    if (!els.promptInput.value.trim() && !els.supplementInput.value.trim() && !state.files.length) return showToast("请描述创意，填写用户补充，或先上传素材。", true);
    if (state.mode === "reverse") {
      if (!state.files.length) return showToast("图像反推需要至少上传一张图片。", true);
      if (state.files.some(item => item.kind !== "image")) return showToast("图像反推只接受图片；视频请使用“解析视频”。", true);
      if (state.files.length !== 1) return showToast("图像反推每次只处理一张图片。", true);
    }
    const config = currentApiConfig(false);
    if (!config.apiKey) { showView(els.settingsView); loadProviderForm(state.settings.providerId); return showToast("请先配置 API Key。", true); }
    if (state.files.length && !modelSupportsVision()) return showToast("当前模型不支持图片输入，请选择多模态模型。", true);
    if (!(await prepareApiAccess(config, false))) return;
    if (state.mode === "analyze") {
      const videos = state.files.filter(item => item.kind === "video");
      if (!videos.length || videos.length !== state.files.length) return showToast("解析视频模式只接受视频；可一次上传多个视频加入队列。", true);
      try {
        const snapshots = videos.map(video => captureSnapshot(config, [video]));
        snapshots.forEach(snapshot => uniformIntervalTimes(snapshot.files[0].duration || 1, snapshot.settings.analysisInterval));
        snapshots.forEach(enqueueSnapshot);
        showToast(`已加入 ${videos.length} 个视频解析任务`);
      } catch (error) { showToast(error.message, true); }
      return;
    }
    const snapshot = captureSnapshot(config);
    try { validateReferenceIntent(snapshot); }
    catch (error) { return showToast(error.message, true); }
    const queued = enqueueSnapshot(snapshot);
    showToast(`已加入任务队列${queued.position > 1 ? ` · 前方 ${queued.position - 1} 项` : ""}`);
  }

  function renderHistory() {
    els.historyList.innerHTML = "";
    if (!state.history.length) { els.historyList.innerHTML = `<div class="empty-state">${escapeHtml(tr("还没有生成记录。"))}<br>${escapeHtml(tr("完成一次生成后会自动保存在这里。"))}</div>`; return; }
    state.history.forEach(item => {
      const card = document.createElement("article");
      card.className = "history-item";
      const historyMode = item.mode === "analyze" ? "视频解析" : item.mode === "reverse" ? "图像反推" : item.mode === "convert-h3" ? "H3 格式转换" : "提示词生成";
      card.innerHTML = `<div class="history-item-head"><strong>${escapeHtml(tr(item.skillTitle))} · ${escapeHtml(tr(historyMode))}</strong><time>${new Date(item.createdAt).toLocaleString(window.GaryI18n.getLocale() === "en" ? "en-US" : "zh-CN")}</time></div><p>${escapeHtml([item.prompt, item.supplement].filter(Boolean).join(" · ") || item.result)}</p>`;
      card.addEventListener("click", () => {
        if (allSkills().some(skill => skill.id === item.skillId)) state.selectedSkillId = item.skillId;
        els.promptInput.value = item.prompt || "";
        els.charCount.textContent = `${els.promptInput.value.length} / 6000`;
        state.result = item.result;
        state.analysisRows = Array.isArray(item.analysisRows) ? item.analysisRows : [];
        state.analysisMeta = item.analysisMeta || null;
        const historySkill = allSkills().find(skill => skill.id === item.skillId);
        state.resultFormat = item.resultFormat || (item.mode === "analyze" ? "analysis" : historySkill?.engine === "h3" ? "h3" : "native");
        renderResult();
        els.resultCard.classList.remove("hidden");
        renderSelectedSkill(); showView(els.workspaceView);
      });
      els.historyList.appendChild(card);
    });
  }

  async function copyResult() {
    if (!state.result) return;
    try { await navigator.clipboard.writeText(state.result); showToast("已复制到剪贴板"); }
    catch (_) {
      const area = document.createElement("textarea"); area.value = state.result; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove(); showToast("已复制到剪贴板");
    }
  }

  function safeFilename(name) {
    return String(name || "gary-prompt").replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, "-").slice(0, 80);
  }

  function exportResult() {
    if (!state.result) return;
    let content = state.result;
    let mime = "text/markdown;charset=utf-8";
    let extension = "md";
    let name = `Gary-Prompt-${new Date().toISOString().slice(0, 10)}`;
    if (state.analysisRows.length && state.analysisMeta) {
      name = `${safeFilename(state.analysisMeta.videoName)}-视频解析`;
      if (state.analysisMeta.output === "table") {
        content = `\ufeff${window.GaryVideoAnalysis.csv(state.analysisRows)}`;
        mime = "text/csv;charset=utf-8";
        extension = "csv";
      }
    }
    const url = URL.createObjectURL(new Blob([content], { type: mime }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `${name}.${extension}`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast(`已导出 ${extension.toUpperCase()} 文件`);
  }

  async function convertResultToH3() {
    if (!state.result || state.resultFormat === "h3" || state.resultFormat === "analysis" || state.resultFormat === "image-reverse") return;
    const config = currentApiConfig(false);
    if (!config.apiKey) { showView(els.settingsView); loadProviderForm(state.settings.providerId); return showToast("请先配置 API Key。", true); }
    if (state.files.length && !modelSupportsVision()) return showToast("转换带参考素材的 H3 提示词需要多模态模型。", true);
    if (!(await prepareApiAccess(config, false))) return;
    const snapshot = captureSnapshot(config);
    snapshot.mode = "convert-h3";
    snapshot.sourceResult = state.result;
    try { validateReferenceIntent(snapshot); }
    catch (error) { return showToast(error.message, true); }
    const queued = window.GaryJobs.enqueue({
      type: "convert-h3",
      timingKey: `convert-h3:${config.providerId}:${config.model}`,
      estimateMs: 48000 + (snapshot.files.length * 1500),
      title: "转换 MiniMax H3",
      label: `${snapshot.skill.title} → MiniMax H3`,
      labelParts: [snapshot.skill.title, "MiniMax H3"],
      labelSeparator: " → ",
      detail: `${providerById(config.providerId).name} · ${config.model}`,
      run: async update => {
        update(3, "正在准备 H3 转换", "冻结原提示词与参考素材语义");
        const prepared = await prepareMedia(snapshot.files, snapshot.settings.frameCount, fraction => update(3 + fraction * 25, "正在预处理参考素材", `${Math.round(fraction * 100)}%`));
        update(31, "正在转换 MiniMax H3", "保留原 Skill 创意，只转换官方结构");
        const systemPrompt = `你是严格的 MiniMax H3 提示词格式转换器。保留源提示词的创意、剧情、角色、产品事实、镜头和声音设计，不重新发散创作；只修正为可直接提交给 H3 的最终格式。<user_supplement priority="must_follow"> 是全局高优先级要求，必须完整合并到最终 H3 正文。禁止输出转换过程、点评或两个版本。\n\n<official_h3_converter>\n${window.GARY_H3_CONVERTER}\n</official_h3_converter>`;
        const userPrompt = `<source_skill>${snapshot.skill.model || snapshot.skill.category} · ${snapshot.skill.title}</source_skill>
<reference_intent>${referenceIntentLabel(snapshot.settings.referenceIntent)}</reference_intent>
<target_settings>时长 ${snapshot.duration}；画幅 ${snapshot.ratio}；输出语言 ${snapshot.settings.language}</target_settings>
<user_supplement priority="must_follow">${snapshot.supplement || "无额外补充要求。"}</user_supplement>
${prepared.mapping ? `<uploaded_media_mapping>\n${prepared.mapping}\n</uploaded_media_mapping>` : "<uploaded_media_mapping>无参考素材，使用 T2VA</uploaded_media_mapping>"}
<source_prompt>
${snapshot.sourceResult}
</source_prompt>

请只输出转换后的 MiniMax H3 成品提示词。模式必须依据 reference_intent 的语义选择，不能只按图片数量判断。`;
        const rawResult = await window.GaryApi.generate(snapshot.config, systemPrompt, userPrompt, prepared.media, retryProgress(update, 31));
        const result = window.GaryOutput.cleanH3(rawResult);
        update(98, "正在完成 H3 转换", "检查模式与最终格式");
        return { result };
      },
      onSuccess: async payload => {
        state.result = payload.result;
        state.resultFormat = "h3";
        state.analysisRows = [];
        state.analysisMeta = null;
        renderResult();
        els.resultCard.classList.remove("hidden");
        state.history.unshift({ id: `${Date.now()}`, createdAt: new Date().toISOString(), skillId: snapshot.skillId, skillTitle: `${snapshot.skill.title} → MiniMax H3`, prompt: snapshot.prompt, supplement: snapshot.supplement, result: payload.result, mode: "convert-h3", resultFormat: "h3" });
        state.history = state.history.slice(0, 20);
        await storage.set("garyHistory", state.history);
        showToast("已转换为 MiniMax H3 格式");
      },
      onError: error => showToast(`H3 格式转换失败：${error.message || error}`, true)
    });
    showToast(`H3 转换已加入队列${queued.position > 1 ? ` · 前方 ${queued.position - 1} 项` : ""}`);
  }

  async function insertIntoPage() {
    if (!state.result) return;
    if (!hasChrome || !chrome.tabs || !chrome.scripting) { await copyResult(); return showToast("预览模式已复制；安装扩展后可直接插入网页。 "); }
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || /^(chrome|edge|about|chrome-extension):/.test(tab.url || "")) throw new Error("当前页面不允许扩展写入，请改用复制。 ");
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        args: [state.result],
        func: (text) => {
          function visible(el) { const rect = el.getBoundingClientRect(); const style = getComputedStyle(el); return rect.width > 20 && rect.height > 15 && style.visibility !== "hidden" && style.display !== "none"; }
          let target = document.activeElement;
          const editable = el => el && (el.matches?.('textarea, input:not([type="hidden"]):not([type="file"])') || el.isContentEditable);
          if (!editable(target) || !visible(target)) {
            const candidates = Array.from(document.querySelectorAll('textarea, [contenteditable="true"], input[type="text"], input:not([type])')).filter(visible);
            target = candidates.sort((a, b) => (b.getBoundingClientRect().width * b.getBoundingClientRect().height) - (a.getBoundingClientRect().width * a.getBoundingClientRect().height))[0];
          }
          if (!target) return false;
          target.focus();
          if (target.isContentEditable) {
            document.execCommand("selectAll", false, null);
            document.execCommand("insertText", false, text);
            target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
          } else {
            const proto = target.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
            setter ? setter.call(target, text) : (target.value = text);
            target.dispatchEvent(new Event("input", { bubbles: true }));
            target.dispatchEvent(new Event("change", { bubbles: true }));
          }
          return true;
        }
      });
      if (results?.[0]?.result) showToast("已插入当前网页的输入框");
      else { await copyResult(); showToast("没有找到输入框，结果已复制。 "); }
    } catch (error) { await copyResult(); showToast(`${error.message} 结果已复制。`, true); }
  }

  function bindEvents() {
    $("#homeButton").addEventListener("click", () => showView(els.workspaceView));
    $("#shareButton").addEventListener("click", shareExtension);
    $("#settingsButton").addEventListener("click", () => { loadProviderForm(state.settings.providerId); els.uiLanguageSelect.value = state.settings.uiLanguage || "auto"; els.languageSelect.value = state.settings.language; els.frameCountSelect.value = String(state.settings.frameCount); els.retryCountSelect.value = String(state.settings.retryCount ?? 2); els.requestTimeoutSelect.value = String(state.settings.requestTimeout || 240); showView(els.settingsView); });
    $("#historyButton").addEventListener("click", () => { renderHistory(); showView(els.historyView); });
    $$('[data-back]').forEach(button => button.addEventListener("click", () => showView(els.workspaceView)));
    els.openSkillLibrary.addEventListener("click", () => { renderCategories(); renderSkillGrid(); showView(els.skillView); });
    els.openSkillLibrary.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); els.openSkillLibrary.click(); } });
    els.skillSearch.addEventListener("input", () => { state.search = els.skillSearch.value.trim(); renderSkillGrid(); });
    els.promptInput.addEventListener("input", () => { els.charCount.textContent = `${els.promptInput.value.length} / 6000`; });
    els.uploadButton.addEventListener("click", () => els.fileInput.click());
    els.fileInput.addEventListener("change", () => addFiles(els.fileInput.files));
    ["dragenter", "dragover"].forEach(type => els.mediaZone.addEventListener(type, event => { event.preventDefault(); els.mediaZone.classList.add("dragover"); }));
    ["dragleave", "drop"].forEach(type => els.mediaZone.addEventListener(type, event => { event.preventDefault(); els.mediaZone.classList.remove("dragover"); }));
    els.mediaZone.addEventListener("drop", event => addFiles(event.dataTransfer.files));
    $$(".mode-chip").forEach(button => button.addEventListener("click", () => {
      state.mode = button.dataset.mode;
      $$(".mode-chip").forEach(item => item.classList.toggle("active", item === button));
      renderMode();
    }));
    els.analysisIntervalSelect.addEventListener("change", async () => {
      state.settings.analysisInterval = Number(els.analysisIntervalSelect.value);
      await storage.set("garySettings", state.settings);
    });
    els.analysisOutputSelect.addEventListener("change", async () => {
      state.settings.analysisOutput = els.analysisOutputSelect.value;
      await storage.set("garySettings", state.settings);
    });
    els.referenceIntentSelect.addEventListener("change", async () => {
      state.settings.referenceIntent = els.referenceIntentSelect.value;
      await storage.set("garySettings", state.settings);
    });
    els.generateButton.addEventListener("click", generate);
    els.copyButton.addEventListener("click", copyResult);
    els.exportButton.addEventListener("click", exportResult);
    els.convertH3Button.addEventListener("click", convertResultToH3);
    els.insertButton.addEventListener("click", insertIntoPage);
    $("#clearResultButton").addEventListener("click", () => { state.result = ""; state.resultFormat = "native"; state.analysisRows = []; state.analysisMeta = null; els.resultContent.textContent = ""; els.resultCard.classList.add("hidden"); });

    els.providerSelect.addEventListener("change", () => {
      saveFormToProviderConfig(state.settings.providerId);
      state.settings.providerId = els.providerSelect.value;
      loadProviderForm(state.settings.providerId);
    });
    els.modelSelect.addEventListener("change", () => els.customModelInput.classList.toggle("hidden", els.modelSelect.value !== "__custom__"));
    els.uiLanguageSelect.addEventListener("change", async () => {
      state.settings.uiLanguage = els.uiLanguageSelect.value;
      await storage.set("garySettings", state.settings);
      window.GaryI18n.setPreference(state.settings.uiLanguage);
    });
    $("#toggleKeyButton").addEventListener("click", event => { const show = els.apiKeyInput.type === "password"; els.apiKeyInput.type = show ? "text" : "password"; event.currentTarget.textContent = tr(show ? "隐藏" : "显示"); });
    els.settingsForm.addEventListener("submit", async event => {
      event.preventDefault();
      state.settings.providerId = els.providerSelect.value;
      saveFormToProviderConfig(state.settings.providerId);
      state.settings.uiLanguage = els.uiLanguageSelect.value;
      state.settings.language = els.languageSelect.value;
      state.settings.frameCount = Number(els.frameCountSelect.value);
      state.settings.retryCount = Number(els.retryCountSelect.value);
      state.settings.requestTimeout = Number(els.requestTimeoutSelect.value);
      const config = currentApiConfig(false);
      if (!config.model) return showToast("请填写模型 ID。", true);
      await storage.set("garySettings", state.settings);
      window.GaryI18n.setPreference(state.settings.uiLanguage);
      renderStatus(); renderMode(); showView(els.workspaceView); showToast("设置已保存");
    });
    els.refreshModelsButton.addEventListener("click", async () => {
      const providerId = els.providerSelect.value;
      saveFormToProviderConfig(providerId);
      const config = currentApiConfig(true);
      if (!config.apiKey && providerId !== "openrouter") return showToast("请先填写 API Key。", true);
      if (!(await prepareApiAccess(config, true))) return;
      setLoading(true, "正在获取模型", "只保留多模态与强力语言模型…");
      try {
        const models = await window.GaryApi.fetchModels(config);
        providerConfig(providerId).models = models;
        providerConfig(providerId).model = models[0].id;
        renderModelOptions(providerId);
        showToast(`已获取 ${models.length} 个可用模型`);
      } catch (error) { showToast(error.message, true); }
      finally { setLoading(false); }
    });
    els.testApiButton.addEventListener("click", async () => {
      saveFormToProviderConfig(els.providerSelect.value);
      const config = currentApiConfig(true);
      if (!(await prepareApiAccess(config, false))) return;
      setLoading(true, "正在测试连接", `${providerById(config.providerId).name} · ${config.model || "未选择模型"}`);
      try { await window.GaryApi.testConnection(config); showToast("连接成功，API 可以使用"); }
      catch (error) { showToast(error.message, true); }
      finally { setLoading(false); }
    });

    $("#addCustomSkillButton").addEventListener("click", () => openCustomSkillDialog());
    $("#closeCustomDialog").addEventListener("click", () => els.customSkillDialog.close());
    $("#cancelCustomSkill").addEventListener("click", () => els.customSkillDialog.close());
    els.customSkillForm.addEventListener("submit", async event => {
      event.preventDefault();
      const existing = state.customSkills.find(item => item.id === state.editingSkillId);
      const skill = {
        id: existing?.id || `custom-${Date.now()}`,
        custom: true,
        category: "自定义",
        displayCategory: els.customSkillCategory.value.trim() || "自定义",
        model: els.customSkillCategory.value.trim() || "自定义",
        icon: "MY",
        title: els.customSkillName.value.trim(),
        short: els.customSkillDescription.value.trim(),
        description: els.customSkillDescription.value.trim(),
        needs: "按自定义规则",
        output: "自定义提示词",
        tags: ["自定义", els.customSkillCategory.value.trim()].filter(Boolean),
        prompt: els.customSkillPrompt.value.trim()
      };
      if (existing) Object.assign(existing, skill); else state.customSkills.unshift(skill);
      await storage.set("garyCustomSkills", state.customSkills);
      els.customSkillDialog.close(); renderCategories(); renderSkillGrid(); showToast(existing ? "Skill 已更新" : "自定义 Skill 已添加");
    });
    $("#clearHistoryButton").addEventListener("click", async () => {
      if (!state.history.length || !confirm(tr("清空全部生成历史？"))) return;
      state.history = []; await storage.set("garyHistory", []); renderHistory();
    });
  }

  async function init() {
    const [settings, customSkills, selectedId, history] = await Promise.all([
      storage.get("garySettings"), storage.get("garyCustomSkills"), storage.get("garySelectedSkill"), storage.get("garyHistory")
    ]);
    if (settings) state.settings = Object.assign(state.settings, settings);
    window.GaryI18n.setPreference(state.settings.uiLanguage || "auto", false);
    state.customSkills = Array.isArray(customSkills) ? customSkills : [];
    state.selectedSkillId = selectedId && allSkills().some(skill => skill.id === selectedId) ? selectedId : "s25-general";
    state.history = Array.isArray(history) ? history : [];
    window.GARY_PROVIDERS.forEach(provider => providerConfig(provider.id));
    renderProviderOptions();
    els.uiLanguageSelect.value = state.settings.uiLanguage || "auto";
    els.languageSelect.value = state.settings.language;
    els.frameCountSelect.value = String(state.settings.frameCount);
    els.retryCountSelect.value = String(state.settings.retryCount ?? 2);
    els.requestTimeoutSelect.value = String(state.settings.requestTimeout || 240);
    els.analysisIntervalSelect.value = String(state.settings.analysisInterval || 3);
    els.analysisOutputSelect.value = state.settings.analysisOutput || "table";
    els.referenceIntentSelect.value = state.settings.referenceIntent || "auto";
    renderSelectedSkill(); renderStatus(); renderMode(); bindEvents();
    window.addEventListener("gary-language-change", () => {
      renderProviderOptions(); renderSelectedSkill(); renderCategories(); renderSkillGrid(); renderStatus(); renderMode(); renderMedia();
      if (!els.historyView.classList.contains("hidden")) renderHistory();
      if (!els.resultCard.classList.contains("hidden")) renderResult();
      loadProviderForm(state.settings.providerId);
      window.GaryI18n.apply(document);
    });
    window.GaryI18n.apply(document);
  }

  init().catch(error => showToast(`初始化失败：${error.message}`, true));
})();
