(function () {
  const en = {
    "你的 AI 视频导演": "Your AI Video Director",
    "把一个想法，变成": "Turn an idea into",
    "可直接生成": "a production-ready",
    "的提示词。": "video prompt.",
    "未配置 API": "API not configured",
    "当前 SKILL": "CURRENT SKILL",
    "描述你的画面或任务": "Describe your scene or task",
    "用户补充（可选）": "Additional requirements (optional)", "全局生效": "GLOBAL", "补充内容会与主任务一起发送，并作为必须执行的要求合并到最终结果。": "These requirements are sent with the main task and must be incorporated into the final result.",
    "例如：加入人物台词“欢迎来到 Gary Prompt”，在第 5 秒说出；保持人物服装不变；不要添加背景音乐……": "Example: Add the line “Welcome to Gary Prompt” at 5 seconds; keep the clothing unchanged; do not add background music…",
    "例如：重点还原服装材质、摄影光线和画面文字；使用专业摄影术语……": "Example: Prioritize clothing materials, photographic lighting, and visible text; use professional photography terms…",
    "仅用于指定反推重点、专业术语或输出偏好；如需新增台词、动作或改写画面，请使用“生成提示词”。": "Use this only to set reverse-engineering focus, terminology, or output preferences. To add dialogue, action, or change the image, use Generate Prompt.",
    "分析重点（可选）": "Analysis focus (optional)", "反推重点（可选）": "Reverse focus (optional)",
    "例如：重点分析人物动作、镜头变化和产品出现的时间……": "Example: Focus on character actions, shot changes, and when the product appears…",
    "例如：重点还原人物、服装、构图、画面文字和原始光影……": "Example: Prioritize the person, clothing, composition, visible text, and original lighting…",
    "图片内容是反推的事实基础；额外台词、动作或改动请填写在下方“用户补充”中。": "The image is the factual foundation. Put additional dialogue, actions, or changes in Additional requirements below.",
    "不填写时执行完整镜头分析；视频音频仍需要单独转写。": "Leave blank for a complete shot analysis. Video audio still requires separate transcription.",
    "目标时长": "Target duration",
    "画幅": "Aspect ratio",
    "上传图片或视频": "Upload images or videos",
    "图像反推 · 视频解析 · 最多 8 个文件": "Image reverse prompting · Video analysis · Up to 8 files",
    "参考素材用途": "Reference purpose",
    "智能判断 · 推荐": "Smart routing · Recommended",
    "首帧图生视频": "First-frame image-to-video",
    "首尾帧过渡": "First/last-frame transition",
    "尾帧反推视频": "Last-frame reverse video",
    "角色 / 产品 / 风格参考": "Character / product / style reference",
    "用途决定提示词如何改写，也决定转换 H3 时使用 I2VA、FL2VA、L2VA 或 Ref2VA。": "This choice controls prompt adaptation and H3 routing to I2VA, FL2VA, L2VA, or Ref2VA.",
    "生成提示词": "Generate prompt",
    "解析视频": "Analyze video",
    "反推提示词": "Reverse prompt", "图像反推": "Image reverse prompting",
    "均匀时间间隔": "Uniform interval",
    "结果形式": "Output format",
    "镜头表格": "Shot table",
    "分析文档": "Analysis document",
    "按每个时间段的中点抽帧；单段视频最多 60 帧。表格一键导出 CSV，文档一键导出 Markdown。": "Samples the midpoint of each interval, up to 60 frames per video. Tables export as CSV; documents export as Markdown.",
    "开始生成": "Generate",
    "加入生成队列": "Add to generation queue",
    "加入反推队列": "Add to reverse queue", "加入图像反推队列": "Add to image reverse queue",
    "加入视频解析队列": "Add videos to analysis queue",
    "上传需要解析的视频": "Upload videos to analyze", "上传需要反推的图片": "Upload an image to reverse", "支持多个视频 · 自动依次排队": "Multiple videos supported · queued automatically", "图片是反推事实来源 · 最多 8 张": "Images are the factual source · up to 8", "上传 1 张图片 · 输出 1 份专业图像提示词": "Upload 1 image · receive 1 professional image prompt", "图像参考 · 视频抽帧 · 最多 8 个文件": "Image references · sampled video · up to 8 files",
    "图像反推不使用当前 Skill，也不会生成视频动作、台词或时间轴。": "Image reverse prompting does not use the selected skill and will not generate video actions, dialogue, or a timeline.",
    "将在浏览器本地预处理素材，然后请求你配置的 API。": "Media is preprocessed locally before calling your configured API.",
    "生成结果": "Result",
    "原格式": "Original format",
    "清空": "Clear",
    "一键复制": "Copy",
    "一键导出": "Export",
    "转为 H3 格式": "Convert to H3",
    "插入网页": "Insert into page",
    "打赏作者": "Support the author",
    "分享给朋友": "Share with friends",
    "调用 API 前请确认": "Confirm before calling an API",
    "你输入的文字、当前 Skill 指令，以及经过本地压缩的图片或视频关键帧，会直接发送给你选择的第三方 API 服务商。": "Your text, selected Skill instructions, and locally compressed images or sampled video frames are sent directly to the third-party API provider you choose.",
    "API Key、设置和生成历史保存在本机浏览器扩展存储中，不会发送给 Gary Prompt 作者或 dream3d.vip。视频只在本地抽帧，不会整段上传。": "Your API key, settings, and history stay in local extension storage and are not sent to the Gary Prompt author or dream3d.vip. Videos are sampled locally and are not uploaded in full.",
    "查看完整隐私说明 ↗": "Read the full privacy notice ↗",
    "暂不同意": "Not now",
    "同意并继续": "Agree and continue",
    "选择创作技能": "Choose a creative skill",
    "＋ 自定义": "+ Custom",
    "搜索用途、模型或关键词": "Search by use, model, or keyword",
    "API 与输出设置": "API & output settings",
    "API 服务商": "API provider",
    "获取 API Key ↗": "Get API Key ↗",
    "API 地址": "API endpoint",
    "显示": "Show",
    "隐藏": "Hide",
    "仅保存在本机浏览器扩展存储中；它不是加密保险库。": "Stored only in local extension storage; this is not an encrypted vault.",
    "模型": "Model",
    "预设仅列出强力语言模型和可处理图像的多模态模型。": "Presets include only strong language models and image-capable multimodal models.",
    "从 API 获取模型": "Fetch models from API",
    "测试连接": "Test connection",
    "界面语言": "Interface language",
    "自动检测浏览器语言": "Auto-detect browser language",
    "界面语言与生成结果语言互相独立。": "Interface language and generated-output language are independent.",
    "输出语言": "Generated output language",
    "简体中文": "Simplified Chinese", "中英双语": "Chinese + English", "设置": "Settings", "返回": "Back", "关闭": "Close",
    "临时错误自动重试": "Retry temporary failures",
    "不自动重试": "No automatic retry",
    "重试 1 次": "Retry once",
    "重试 2 次 · 推荐": "Retry twice · Recommended",
    "单次请求超时": "Per-request timeout",
    "2 分钟": "2 minutes",
    "4 分钟 · 推荐": "4 minutes · Recommended",
    "6 分钟": "6 minutes",
    "只重试网络中断/超时、响应不完整、429 限流和服务商 5xx 故障；欠费、Key 错误、模型无权限和参数问题不会自动重试。响应丢失后重试可能产生第二次计费。": "Only network/timeout, incomplete responses, rate limits, and provider 5xx errors are retried. Billing, key, model permission, and request errors are not. Retrying a lost response may incur another charge.",
    "生成/反推模式的视频抽帧数": "Video frames for generate/reverse modes", "生成模式的视频抽帧数": "Video frames for Generate mode",
    "“解析视频”模式使用工作区里的均匀时间间隔，不使用此项。": "Video Analysis uses the uniform interval in the workspace instead.",
    "保存设置": "Save settings",
    "生成历史": "History",
    "全部清空": "Clear all",
    "添加自定义 Skill": "Add custom skill",
    "名称": "Name",
    "分类": "Category",
    "简介": "Description",
    "Skill 指令": "Skill instructions",
    "取消": "Cancel",
    "保存 Skill": "Save skill",
    "任务队列": "Task queue",
    "准备处理": "Ready",
    "等待中": "Waiting",
    "清理": "Clear",
    "继续队列": "Resume queue",
    "每 1 秒": "Every 1 second",
    "每 2 秒": "Every 2 seconds",
    "每 3 秒 · 推荐": "Every 3 seconds · Recommended",
    "每 5 秒": "Every 5 seconds",
    "每 10 秒": "Every 10 seconds",
    "每 15 秒": "Every 15 seconds",
    "每 30 秒": "Every 30 seconds",
    "5 秒": "5 seconds", "10 秒": "10 seconds", "15 秒": "15 seconds", "30 秒": "30 seconds", "60 秒": "60 seconds",
    "自适应": "Auto", "4 帧 · 更省 Token": "4 frames · Fewer tokens", "6 帧 · 推荐": "6 frames · Recommended", "8 帧 · 更细致": "8 frames · More detail", "12 帧 · 长视频": "12 frames · Longer video",

    "通用导演": "General Director",
    "动作导演": "Action Director",
    "对白与情绪表演": "Dialogue & Emotional Performance",
    "多模态参考复刻": "Multimodal Reference Recreation",
    "全能生成": "All-purpose Generation",
    "真人角色锚定": "Live-action Character Anchoring",
    "长视频与超长叙事": "Long-form Storytelling",
    "视频延长与续写": "Video Extension & Continuation",
    "智能视频编辑": "Intelligent Video Editing",
    "创意迁移与无缝转场": "Creative Transfer & Seamless Transitions",
    "H3 五模式通用提示词": "H3 Five-mode Universal Prompt",
    "H3 全参考 Ref2VA": "H3 Full-reference Ref2VA",
    "3D 动画短片": "3D Animated Short",
    "品牌宣传短片": "Brand Promo Film",
    "极简产品广告": "Minimal Product Commercial",
    "MV 与歌词排版": "Music Video & Lyric Typography",
    "纸拼贴科普": "Paper-collage Explainer",
    "纸艺定格科普": "Papercraft Stop-motion Explainer",
    "手绘发光 × 实拍": "Glowing Hand-drawn × Live Action",
    "双人游戏开场": "Two-player Game Intro",

    "动作、对话、氛围场景的双语电影化分镜": "Cinematic bilingual shot design for action, dialogue, and atmosphere",
    "战斗、追逐、跑酷与复杂特技的因果链设计": "Causal action design for fights, chases, parkour, and complex stunts",
    "对峙、谈判、审讯与微表情驱动的文戏": "Dialogue scenes driven by confrontation, negotiation, interrogation, and micro-expressions",
    "从图片/视频提取角色、动作、镜头和风格锚点": "Extract character, action, camera, and style anchors from images or video",
    "多模态参考、时间轴与声音的一站式导演": "All-in-one direction for multimodal references, timelines, and sound",
    "高辨识度人物、群像绑定与情绪表演": "Distinctive characters, ensemble consistency, and emotional performance",
    "30–180 秒故事、分段节拍与帧级时间轴": "30–180 second stories with segmented beats and frame-level timelines",
    "向前/向后延长、跨场景衔接与多次续写": "Forward/backward extension, scene bridges, and iterative continuation",
    "替换、删除、局部修改、视角与光影重构": "Replacement, removal, local edits, camera, and lighting reconstruction",
    "镜头语言迁移、卡点复刻、多宫格与白模控制": "Camera-language transfer, beat recreation, grid layouts, and blockout control",
    "T2VA、I2VA、FL2VA、L2VA 与 Ref2VA 自动路由": "Automatic routing across T2VA, I2VA, FL2VA, L2VA, and Ref2VA",
    "人物、图片、视频与音频的六段式保真分析": "Six-part fidelity analysis for people, images, video, and audio",
    "从故事到角色卡、镜头表与成片提示词": "From story to character cards, shot lists, and production prompts",
    "品牌事实、产品能力、使用场景与 CTA 的完整叙事": "Complete narrative spanning brand facts, product value, use cases, and CTA",
    "电商新品、材质卖点与节拍排版的高级产品片": "Premium product films for launches, materials, features, and rhythmic typography",
    "节拍、表演、空间文字与多镜头拼接": "Beat, performance, spatial typography, and multi-shot assembly",
    "半调照片剪纸、纸张层次与触觉定格动画": "Halftone photo cutouts, layered paper, and tactile stop motion",
    "立体纸模、分层场景与微缩定格讲解": "Dimensional papercraft, layered scenes, and miniature stop-motion explanation",
    "粗粝发光线条接触现实物体并连续变形追逐": "Rough glowing lines interact with real objects through continuous transformation",
    "角色卡、玩家名与菜单交互驱动的游戏 Intro": "A game intro driven by character cards, player names, and menu interaction",

    "文字，可选图片/视频": "Text; optional images/video",
    "剧情/招式，可选角色图": "Plot/moves; optional character images",
    "人物关系、台词、情绪": "Relationships, dialogue, and emotion",
    "至少一张图或一段视频": "At least one image or video",
    "创意，可选图/视频/音频": "Concept; optional image/video/audio",
    "人物设定或角色参考图": "Character brief or reference image",
    "故事梗概、目标时长": "Story outline and target duration",
    "原视频 + 续写方向": "Source video + continuation direction",
    "待编辑视频 + 修改目标": "Video to edit + requested changes",
    "参考视频/分镜图 + 新内容": "Reference video/storyboard + new content",
    "创意；按模式上传参考": "Concept; references according to mode",
    "图片/视频/音频参考": "Image/video/audio references",
    "故事点子、时长、画幅": "Story idea, duration, and aspect ratio",
    "Logo/产品图/官网信息": "Logo, product images, and website facts",
    "至少一张产品图": "At least one product image",
    "音乐/歌词/节拍信息": "Music, lyrics, and beat information",
    "知识点/旁白/观点": "Facts, narration, and viewpoint",
    "主题、受众、知识点": "Topic, audience, and key facts",
    "实拍场景、接触物、情绪": "Live-action setting, contact object, and emotion",
    "两位玩家名、游戏名、角色参考": "Two player names, game title, and character references",

    "成品提示词 + 镜头节拍": "Production prompt + shot beats",
    "秒级动作提示词": "Second-by-second action prompt",
    "对白分镜 + 表演指令": "Dialogue storyboard + performance direction",
    "素材映射 + 生成提示词": "Asset mapping + generation prompt",
    "完整 2.5 提示词": "Complete 2.5 prompt",
    "人物锚点 + 表演提示词": "Character anchors + performance prompt",
    "全局设定 + 长时间轴": "Global setup + long timeline",
    "延长专用提示词": "Extension-specific prompt",
    "精确编辑指令": "Precise editing instructions",
    "迁移映射 + 转场提示词": "Transfer mapping + transition prompt",
    "H3 英文标准结构": "Standard English H3 structure",
    "Ref2VA 六段式英文提示词": "Six-part English Ref2VA prompt",
    "制作方案 + H3 分镜提示词": "Production plan + H3 shot prompts",
    "广告创意 + 成片提示词": "Campaign concept + production prompt",
    "产品锚点 + 广告提示词": "Product anchors + commercial prompt",
    "MV 概念 + 镜头提示词": "Music-video concept + shot prompts",
    "视觉隐喻 + 拼贴提示词": "Visual metaphor + collage prompt",
    "纸艺方案 + 分镜提示词": "Papercraft direction + shot prompts",
    "15 秒融合视频提示词": "15-second hybrid-video prompt",
    "菜单框架 + H3 提示词": "Menu framework + H3 prompt",

    "全部": "All", "自定义": "Custom", "用途": "Use", "需要": "Needs", "产出": "Output", "编辑": "Edit", "删除": "Delete", "已选择": "Selected",
    "常用预设": "Featured presets", "其他服务": "Other services", "手动输入模型 ID…": "Enter a model ID manually…", "图片": "Image", "移除": "Remove", "移除排队任务": "Remove queued job", "展开任务队列": "Expand job queue", "收起任务队列": "Collapse job queue", "手动重试": "Manual retry",
    "文字描述": "Text description", "成品提示词": "Production-ready prompt", "自动套用官方 H3 模板": "Official H3 template applied automatically", "MiniMax 官方开源": "Official MiniMax open source", "基于 MiniMax 官方模板": "Based on the official MiniMax template",
    "没有找到匹配的 Skill。": "No matching skill found.", "可以换个关键词，或添加自己的 Skill。": "Try another keyword or add your own skill.",
    "视频只在浏览器本地解码和均匀抽帧；抽出的帧会提交给你配置的多模态 API。": "Videos are decoded and sampled locally; extracted frames are sent to your configured multimodal API.",
    "请先在右上角设置中配置 API、模型与输出语言。": "Configure an API, model, and output language in Settings first.",
    "视频解析": "Video analysis", "图像提示词": "Image prompt", "原 Skill 格式": "Original skill format", "已是 H3 格式": "Already H3", "解析结果不可转换": "Analysis cannot be converted", "图像反推结果不可转换": "Image reverse results cannot be converted",
    "时间": "Time", "景别": "Shot size", "主体/动作": "Subject / action", "场景": "Scene", "运镜判断": "Camera assessment", "风格": "Style", "画面描述": "Visual description",
    "静态帧不能确认真实运镜；对白与音效未分析，需要音频转写。": "Static frames cannot confirm camera movement. Dialogue and sound are not analyzed and require audio transcription.",
    "还没有生成记录。": "No history yet.", "完成一次生成后会自动保存在这里。": "Completed jobs are saved here automatically.", "提示词反推": "Prompt reverse engineering", "H3 格式转换": "H3 format conversion", "提示词生成": "Prompt generation",
    "运行中": "Running", "等待": "Queued", "完成": "Done", "失败": "Failed", "重试": "Retry", "未知错误": "Unknown error", "等待开始": "Waiting to start", "任务已完成": "Jobs completed", "任务队列已暂停": "Queue paused", "暂无运行任务": "No active job", "暂停": "Paused", "任务执行失败": "Job failed", "处理中": "Processing", "正在处理本地操作": "Processing local operation",
    "处理欠费或 Key 问题后，重试失败任务或继续队列": "Fix billing or key issues, then retry the failed job or resume the queue",
    "请根据提示处理后，在任务行点击“重试”": "Follow the guidance, then click Retry on the failed job",
    "正在读取素材": "Reading media", "生成本地预览，不会上传到其他地方。": "Creating a local preview; nothing is uploaded elsewhere.", "正在获取模型": "Fetching models", "只保留多模态与强力语言模型…": "Keeping only multimodal and strong language models…", "正在测试连接": "Testing connection",
    "正在均匀抽帧": "Sampling frames uniformly", "正在整理分析结果": "Preparing analysis results", "生成 Markdown 文档": "Creating a Markdown document", "生成镜头表格": "Creating a shot table", "正在读取图片细节": "Reading image details", "正在专业反推图像": "Reverse-engineering the image", "正在整理图像提示词": "Finalizing the image prompt", "移除分析说明，只保留最终提示词": "Removing analysis and keeping only the final prompt", "专业图像反推": "Professional image reverse prompting", "正在预处理参考素材": "Preprocessing reference media", "正在整理创作要求": "Preparing the creative brief", "正在调用大模型": "Calling the AI model", "正在整理最终提示词": "Finalizing the prompt", "应用 MiniMax H3 官方结构": "Applying the official MiniMax H3 structure", "检查格式与素材映射": "Checking format and media mapping", "转换 MiniMax H3": "Convert to MiniMax H3", "正在准备 H3 转换": "Preparing H3 conversion", "冻结原提示词与参考素材语义": "Preserving the source prompt and reference semantics", "正在转换 MiniMax H3": "Converting to MiniMax H3", "保留原 Skill 创意，只转换官方结构": "Preserving the skill's creative intent and converting only the official structure", "正在完成 H3 转换": "Finishing H3 conversion", "检查模式与最终格式": "Checking mode and final format",
    "设置已保存": "Settings saved", "连接成功，API 可以使用": "Connection successful", "已复制到剪贴板": "Copied to clipboard", "已转换为 MiniMax H3 格式": "Converted to MiniMax H3", "视频解析已完成": "Video analysis completed", "图像反推已完成": "Image reverse prompting completed", "提示词生成已完成": "Prompt generation completed", "已打开系统分享面板": "System share panel opened", "分享文案和安装链接已复制": "Share message and install link copied", "需要同意数据处理说明后才能调用 API。": "Agree to the data-handling notice before calling an API.", "未获得 API 域名访问权限，无法发送请求。": "API domain access was not granted, so the request cannot be sent.",
    "请选择图片或视频文件。": "Select image or video files.", "请选择图片文件。": "Select an image file.", "最多上传 8 个文件。": "You can upload up to 8 files.", "请描述创意，或先上传素材。": "Describe your idea or upload reference media first.", "请描述创意，填写用户补充，或先上传素材。": "Describe your idea, add requirements, or upload reference media first.", "请先配置 API Key。": "Configure an API key first.", "当前模型不支持图片输入，请选择多模态模型。": "The current model does not support image input. Choose a multimodal model.", "解析视频模式只接受视频；可一次上传多个视频加入队列。": "Video Analysis accepts videos only. You can add multiple videos to the queue at once.", "图像反推需要至少上传一张图片。": "Image reverse prompting requires one image.", "图像反推只接受图片；视频请使用“解析视频”。": "Image reverse prompting accepts images only. Use Video Analysis for video files.", "图像反推每次只处理一张图片。": "Image reverse prompting processes one image at a time.", "转换带参考素材的 H3 提示词需要多模态模型。": "Converting an H3 prompt with reference media requires a multimodal model.", "请填写模型 ID。": "Enter a model ID.", "请先填写 API Key。": "Enter an API key first.",
    "预览模式已复制；安装扩展后可直接插入网页。 ": "Copied in preview mode. Install the extension to insert directly into a webpage.", "已插入当前网页的输入框": "Inserted into the current page's input field", "没有找到输入框，结果已复制。 ": "No input field was found; the result was copied.", "Skill 已更新": "Skill updated", "自定义 Skill 已添加": "Custom skill added", "清空全部生成历史？": "Clear all generation history?", "图片解码失败": "Image decoding failed", "视频抽帧超时": "Video frame extraction timed out", "视频帧读取失败": "Failed to read a video frame",
    "搜索用途、模型或关键词": "Search by use, model, or keyword", "例如：雨夜的东京街头，一位红衣女孩撑伞回头，镜头缓慢环绕，想做 15 秒电影感短片……": "Example: On a rainy Tokyo street, a girl in red turns under an umbrella as the camera slowly circles—create a 15-second cinematic clip…",
    "输入模型 ID": "Enter model ID", "例如：我的武侠动作导演": "Example: My Wuxia Action Director", "告诉用户这个 Skill 适合做什么": "Explain what this skill is best for", "粘贴完整的系统提示词、规则或 SKILL.md 内容……": "Paste the full system prompt, rules, or SKILL.md content…",

    "常用预设 · OpenAI 兼容；可用 GLM、Kimi、Qwen-VL 等强力/多模态模型。": "Common preset · OpenAI-compatible; supports strong and multimodal GLM, Kimi, and Qwen-VL models.",
    "常用预设 · Kimi 开放平台兼容接口；可刷新模型或手动填写最新模型 ID。": "Common preset · Kimi-compatible endpoint; refresh models or enter the latest model ID manually.",
    "常用预设 · 国内 API；国际版可将域名改为 api.minimax.io。M3 视觉能力请以账户实际开放模型为准。": "Common preset · China API. For global access, change the host to api.minimax.io. M3 vision availability depends on your account.",
    "常用预设 · 百炼 OpenAI 兼容接口；推荐 Qwen3-VL 做图片与视频抽帧解析。": "Common preset · Model Studio OpenAI-compatible endpoint; Qwen3-VL is recommended for image and sampled-video analysis.",
    "常用预设 · GLM 文本与视觉模型；视频会在浏览器本地均匀抽帧后提交。": "Common preset · GLM text and vision models; videos are sampled locally before submission.",
    "常用预设 · OpenAI 兼容；agnes-2.0-flash 支持文本与图像理解。": "Common preset · OpenAI-compatible; agnes-2.0-flash supports text and image understanding.",
    "常用预设 · 强力语言模型，适合纯文本提示词；当前不用于图片/视频解析。": "Common preset · Strong text models for text-only prompting; not used for image/video analysis.",
    "官方 Responses API；支持文本与图片输入。视频会在本地抽帧。": "Official Responses API with text and image input; videos are sampled locally.",
    "Gemini 原生 API；适合图片与视频关键帧理解。": "Native Gemini API for image and sampled-video understanding.",
    "Claude Messages API；当前模型支持文本与图片输入。": "Claude Messages API with text and image input.",
    "聚合多家模型；可从 API 拉取并筛选多模态/强力模型。": "Multi-provider gateway; fetch and filter multimodal or strong models from the API.",
    "适用于 Ollama、LM Studio、中转站或其他 OpenAI 兼容接口。": "For Ollama, LM Studio, gateways, and other OpenAI-compatible endpoints."
  };

  const nodeOriginals = new WeakMap();
  const attrOriginals = new WeakMap();
  let preference = "auto";
  let locale = "zh-CN";

  function resolveLocale(value) {
    if (value && value !== "auto") return value === "en" ? "en" : "zh-CN";
    return /^zh\b/i.test(navigator.language || "") ? "zh-CN" : "en";
  }

  function text(value) {
    const source = String(value ?? "");
    if (locale !== "en") return source;
    if (en[source]) return en[source];
    const replacements = [
      [/^需要：/, "Needs: "], [/^产出：/, "Output: "], [/^已加入 (\d+) 个视频解析任务$/, "Added $1 video analysis jobs"],
      [/^已加入任务队列 · 前方 (\d+) 项$/, "Added to queue · $1 ahead"], [/^已加入任务队列$/, "Added to queue"], [/^前方 (\d+) 项$/, "$1 ahead"], [/^已获取 (\d+) 个可用模型$/, "Fetched $1 available models"],
      [/^视频 · ([\d.]+|\?) 秒$/, "Video · $1s"], [/^(\d+) 秒$/, "$1 seconds"], [/^(\d+) 帧$/, "$1 frames"],
      [/^正在抽取第 (\d+)\/(\d+) 帧$/, "Extracting frame $1/$2"], [/^正在解析第 (\d+)[–-](\d+) 帧$/, "Analyzing frames $1–$2"], [/^已完成 (\d+)\/(\d+) 帧$/, "Completed $1/$2 frames"],
      [/^生成提示词失败：/, "Prompt generation failed: "], [/^反推提示词失败：/, "Prompt reverse engineering failed: "], [/^图像反推失败：/, "Image reverse prompting failed: "], [/^解析视频失败：/, "Video analysis failed: "],
      [/^H3 格式转换失败：/, "H3 conversion failed: "], [/^H3 转换已加入队列 · 前方 (\d+) 项$/, "H3 conversion added to queue · $1 ahead"], [/^H3 转换已加入队列$/, "H3 conversion added to queue"],
      [/^已导出 ([A-Z]+) 文件$/, "Exported $1 file"], [/^(.+) 超过 500MB，已跳过。$/, "$1 exceeds 500 MB and was skipped."], [/^无法解析视频 (.+)$/, "Unable to parse video $1"], [/^初始化失败：/, "Initialization failed: "],
      [/^当前参考用途至少需要上传 1 张图片。$/, "This reference mode requires at least one image."], [/^首尾帧过渡需要至少 2 张图片，并按首帧、尾帧顺序上传。$/, "First/last-frame transition requires at least two images uploaded in first-frame, last-frame order."],
      [/^当前间隔会抽取 (\d+) 帧，单段视频最多 60 帧。请增大均匀时间间隔。$/, "This interval would sample $1 frames. A video is limited to 60 frames; increase the interval."]
    ];
    let translated = source;
    replacements.forEach(([pattern, replacement]) => { translated = translated.replace(pattern, replacement); });
    translated = translated
      .replace(/ · 多模态/g, " · Multimodal")
      .replace(/ · 强力文本/g, " · Powerful text")
      .replace(/ · 强力/g, " · Powerful")
      .replace(/ · 快速/g, " · Fast")
      .replace(/ · 推荐/g, " · Recommended")
      .replace(/ · 最强/g, " · Most capable")
      .replace(/ · 均衡/g, " · Balanced")
      .replace(/ · 高性价比/g, " · Cost-effective")
      .replace(/ · 深度推理/g, " · Deep reasoning")
      .replace(/ · 稳定兼容/g, " · Stable and compatible")
      .replace(/ · 复杂任务/g, " · Complex tasks")
      .replace(/ · 速度与能力/g, " · Speed and capability");
    return translated;
  }

  function message(key, fallback, vars) {
    let value = locale === "en" ? (en[key] || fallback || key) : (fallback || key);
    Object.entries(vars || {}).forEach(([name, replacement]) => { value = value.replaceAll(`{${name}}`, replacement); });
    return value;
  }

  function apply(root) {
    const container = root || document;
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      if (["SCRIPT", "STYLE"].includes(node.parentElement?.tagName)) return;
      if (!nodeOriginals.has(node)) nodeOriginals.set(node, node.nodeValue);
      const original = nodeOriginals.get(node);
      const trimmed = original.trim();
      if (!trimmed) return;
      node.nodeValue = original.replace(trimmed, text(trimmed));
    });
    container.querySelectorAll?.("[placeholder], [title], [aria-label]").forEach(element => {
      if (!attrOriginals.has(element)) attrOriginals.set(element, {});
      const originals = attrOriginals.get(element);
      ["placeholder", "title", "aria-label"].forEach(attribute => {
        if (!element.hasAttribute(attribute)) return;
        if (!(attribute in originals)) originals[attribute] = element.getAttribute(attribute);
        element.setAttribute(attribute, text(originals[attribute]));
      });
    });
    document.documentElement.lang = locale;
    document.documentElement.dataset.locale = locale;
  }

  function setPreference(value, notify = true) {
    preference = value || "auto";
    locale = resolveLocale(preference);
    apply(document);
    if (notify) window.dispatchEvent(new CustomEvent("gary-language-change", { detail: { preference, locale } }));
  }

  window.GaryI18n = { text, t: message, apply, setPreference, getPreference: () => preference, getLocale: () => locale };
})();
