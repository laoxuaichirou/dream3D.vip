(function () {
  const $ = selector => document.querySelector(selector);
  const els = {
    dock: $("#jobDock"), body: $("#jobDockBody"), title: $("#jobTitle"), detail: $("#jobDetail"),
    progressText: $("#jobProgressText"), progressPercent: $("#jobProgressPercent"), progressBar: $("#jobProgressBar"),
    list: $("#jobList"), toggle: $("#toggleJobDock"), clear: $("#clearFinishedJobs"), resume: $("#resumeJobQueue")
  };
  const jobs = [];
  let active = null;
  let transient = null;
  let collapsed = false;
  let processing = false;
  let paused = false;
  let pausedReason = "";
  const tr = value => window.GaryI18n?.text(value) || value;

  function timingStats() {
    try { return JSON.parse(localStorage.getItem("garyJobTimings") || "{}"); } catch (_) { return {}; }
  }

  function estimateFor(spec) {
    const stats = timingStats()[spec.timingKey || spec.type];
    return stats?.mean > 2000 ? stats.mean : Number(spec.estimateMs || 45000);
  }

  function recordTiming(job, elapsed) {
    const key = job.timingKey || job.type;
    const stats = timingStats();
    const previous = stats[key];
    stats[key] = previous
      ? { mean: Math.round((previous.mean * .7) + (elapsed * .3)), count: previous.count + 1 }
      : { mean: Math.round(elapsed), count: 1 };
    try { localStorage.setItem("garyJobTimings", JSON.stringify(stats)); } catch (_) {}
  }

  function formatTime(ms) {
    const seconds = Math.max(1, Math.round(ms / 1000));
    if (seconds < 60) return window.GaryI18n?.getLocale() === "en" ? `${seconds}s` : `${seconds} 秒`;
    const minutes = Math.floor(seconds / 60);
    const rest = seconds % 60;
    if (window.GaryI18n?.getLocale() === "en") return rest ? `${minutes}m ${rest}s` : `${minutes} min`;
    return rest ? `${minutes} 分 ${rest} 秒` : `${minutes} 分钟`;
  }

  function displayProgress(job) {
    if (!job || !job.startedAt) return job?.progress || 0;
    const elapsed = Date.now() - job.startedAt;
    const timeProgress = Math.min(94, Math.round((elapsed / job.estimatedMs) * 90));
    return Math.max(job.progress || 0, timeProgress);
  }

  function etaText(job, progress) {
    if (!job?.startedAt) return tr("等待开始");
    if (progress >= 100) return window.GaryI18n?.getLocale() === "en" ? `Done · ${formatTime(job.finishedAt - job.startedAt)}` : `完成 · 用时 ${formatTime(job.finishedAt - job.startedAt)}`;
    const elapsed = Date.now() - job.startedAt;
    const remaining = job.estimatedMs - elapsed;
    const learned = timingStats()[job.timingKey || job.type]?.count > 0;
    if (remaining <= 0) return window.GaryI18n?.getLocale() === "en" ? `Elapsed ${formatTime(elapsed)} · over estimate, still working` : `已用时 ${formatTime(elapsed)} · 超过预估，仍在处理`;
    if (window.GaryI18n?.getLocale() === "en") return `${learned ? "Historical estimate" : "Initial estimate"} · about ${formatTime(remaining)} left`;
    return `${learned ? "历史预估" : "首次预估"} · 约剩 ${formatTime(remaining)}`;
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
  }

  function displayLabel(job) {
    if (!job.labelParts?.length) return tr(job.label || job.title);
    return job.labelParts.map(tr).join(job.labelSeparator || " · ");
  }

  function renderList() {
    els.list.innerHTML = jobs.slice(-8).map(job => {
      const status = tr(job.status === "running" ? "运行中" : job.status === "queued" ? "等待" : job.status === "success" ? "完成" : "失败");
      const progress = job.status === "success" ? 100 : displayProgress(job);
      const action = job.status === "queued"
        ? `<button type="button" data-cancel-job="${job.id}" aria-label="${escapeHtml(tr("移除排队任务"))}">×</button>`
        : job.status === "error" ? `<button type="button" data-retry-job="${job.id}">${escapeHtml(tr("重试"))}</button>` : "";
      const statusText = job.status === "error" ? `${tr("失败")} · ${job.error || tr("未知错误")}` : `${status}${job.status === "running" ? ` · ${progress}%` : ""}`;
      return `<div class="job-row ${job.status}" title="${escapeHtml(job.error || "")}"><i></i><div><strong>${escapeHtml(displayLabel(job))}</strong><span>${escapeHtml(statusText)}</span></div>${action}</div>`;
    }).join("");
  }

  function render() {
    const current = active || transient;
    const visible = Boolean(current || jobs.length);
    els.dock.classList.toggle("hidden", !visible);
    els.dock.classList.toggle("collapsed", collapsed);
    els.toggle.textContent = collapsed ? "⌃" : "⌄";
    els.toggle.setAttribute("aria-label", tr(collapsed ? "展开任务队列" : "收起任务队列"));
    els.resume.classList.toggle("hidden", !paused);
    if (!current) {
      els.title.textContent = tr(paused ? "任务队列已暂停" : "任务队列");
      els.detail.textContent = paused ? pausedReason : tr(jobs.some(job => job.status === "queued") ? "等待开始" : "任务已完成");
      els.progressText.textContent = tr(paused ? "处理欠费或 Key 问题后，重试失败任务或继续队列" : "暂无运行任务");
      els.progressPercent.textContent = paused ? tr("暂停") : "—";
      els.progressBar.style.width = "0%";
      els.dock.classList.remove("working");
    } else if (current.status === "error") {
      els.title.textContent = `${tr(current.title)} · ${tr("失败")}`;
      els.detail.textContent = current.error || tr("任务执行失败");
      els.progressText.textContent = tr("请根据提示处理后，在任务行点击“重试”");
      els.progressPercent.textContent = tr("失败");
      els.progressBar.style.width = `${Math.min(100, current.progress || 0)}%`;
      els.dock.classList.remove("working");
    } else {
      const progress = current.transient ? null : displayProgress(current);
      els.title.textContent = tr(current.title);
      els.detail.textContent = tr(current.detail || "处理中");
      els.progressText.textContent = current.transient ? tr("正在处理本地操作") : etaText(current, progress);
      els.progressPercent.textContent = current.transient ? "…" : `${progress}%`;
      els.progressBar.style.width = current.transient ? "18%" : `${progress}%`;
      els.dock.classList.toggle("working", current.transient || current.status === "running");
    }
    renderList();
  }

  function updateJob(job, progress, title, detail) {
    if (Number.isFinite(progress)) job.progress = Math.max(job.progress || 0, Math.min(99, Math.round(progress)));
    if (title) job.title = title;
    if (detail) job.detail = detail;
    render();
  }

  async function processNext() {
    if (processing || active || paused) return;
    const job = jobs.find(item => item.status === "queued");
    if (!job) { render(); return; }
    processing = true;
    transient = null;
    active = job;
    job.status = "running";
    job.startedAt = Date.now();
    job.estimatedMs = estimateFor(job);
    job.progress = 1;
    render();
    try {
      const result = await job.run((progress, title, detail) => updateJob(job, progress, title, detail));
      job.status = "success";
      job.progress = 100;
      job.finishedAt = Date.now();
      recordTiming(job, job.finishedAt - job.startedAt);
      render();
      await job.onSuccess?.(result);
    } catch (error) {
      job.status = "error";
      job.error = error?.message || String(error);
      job.detail = job.error;
      if (["billing", "auth"].includes(error?.category)) {
        paused = true;
        pausedReason = error.message;
      }
      job.finishedAt = Date.now();
      render();
      await job.onError?.(error);
    } finally {
      await new Promise(resolve => setTimeout(resolve, 500));
      active = null;
      processing = false;
      render();
      processNext();
    }
  }

  function enqueue(spec) {
    const job = {
      ...spec,
      id: `job-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      status: "queued",
      progress: 0,
      createdAt: Date.now()
    };
    if (spec.priority) {
      const queuedIndex = jobs.findIndex(item => item.status === "queued");
      queuedIndex >= 0 ? jobs.splice(queuedIndex, 0, job) : jobs.push(job);
    } else jobs.push(job);
    render();
    queueMicrotask(processNext);
    return { id: job.id, position: (active ? 1 : 0) + jobs.filter(item => item.status === "queued").length };
  }

  function setTransient(show, title, detail) {
    transient = show ? { transient: true, title: title || "正在处理", detail: detail || "请稍候" } : null;
    render();
  }

  els.toggle.addEventListener("click", () => { collapsed = !collapsed; render(); });
  els.clear.addEventListener("click", () => {
    for (let index = jobs.length - 1; index >= 0; index--) {
      if (["success", "error"].includes(jobs[index].status)) jobs.splice(index, 1);
    }
    render();
  });
  els.resume.addEventListener("click", () => { paused = false; pausedReason = ""; render(); processNext(); });
  els.list.addEventListener("click", event => {
    const retryButton = event.target.closest("[data-retry-job]");
    if (retryButton) {
      const failed = jobs.find(job => job.id === retryButton.dataset.retryJob && job.status === "error");
      if (failed) {
        paused = false;
        pausedReason = "";
        enqueue({
          priority: true,
          type: failed.type, timingKey: failed.timingKey, estimateMs: failed.estimateMs,
          title: failed.title.replace(/ · 失败$/, ""), label: failed.label, labelParts: failed.labelParts,
          labelSeparator: failed.labelSeparator, detail: "手动重试",
          run: failed.run, onSuccess: failed.onSuccess, onError: failed.onError
        });
      }
      return;
    }
    const button = event.target.closest("[data-cancel-job]");
    if (!button) return;
    const index = jobs.findIndex(job => job.id === button.dataset.cancelJob && job.status === "queued");
    if (index >= 0) jobs.splice(index, 1);
    render();
  });
  setInterval(() => { if (active) render(); }, 500);
  window.addEventListener("gary-language-change", render);

  window.GaryJobs = { enqueue, setTransient, hasActive: () => Boolean(active), isPaused: () => paused, pendingCount: () => jobs.filter(job => job.status === "queued").length };
})();
