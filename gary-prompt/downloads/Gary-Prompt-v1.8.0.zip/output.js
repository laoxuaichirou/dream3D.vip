(function () {
  function stripFence(value) {
    return String(value || "")
      .trim()
      .replace(/^```(?:ya?ml|text|markdown)?\s*/i, "")
      .replace(/\s*```\s*$/i, "")
      .trim();
  }

  function cleanH3(value) {
    const text = stripFence(value);
    const starts = [
      /^subject_definitions\s*:/im,
      /^For the target video,\s*at 0\.00 seconds/im,
      /^How the reference pictures align with the target video\s*[—:-]/im,
      /^integrated_multimodal_description\s*:/im
    ];
    const indexes = starts
      .map(pattern => pattern.exec(text)?.index)
      .filter(index => Number.isInteger(index));
    const cleaned = indexes.length ? text.slice(Math.min(...indexes)) : text;
    return stripFence(cleaned);
  }

  function cleanImagePrompt(value) {
    const text = stripFence(value);
    const marker = /^#{1,6}\s*(?:最终)?(?:图像|图片)?提示词\s*[:：]?\s*$/im.exec(text);
    const cleaned = marker ? text.slice(marker.index + marker[0].length) : text;
    return stripFence(cleaned).replace(/^(?:最终)?(?:图像|图片)?提示词\s*[:：]\s*/i, "").trim();
  }

  window.GaryOutput = { cleanH3, cleanImagePrompt };
})();
