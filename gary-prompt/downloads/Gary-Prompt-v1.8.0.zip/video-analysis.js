(function () {
  const FIELDS = [
    "shotType", "cameraMovement", "subject", "action", "scene", "composition",
    "lighting", "color", "style", "screenText", "dialogue", "sound",
    "uncertainties", "confidence", "description"
  ];

  const FIELD_ALIASES = {
    shotType: ["shotType", "shot_type", "景别", "镜头类型"],
    cameraMovement: ["cameraMovement", "camera_movement", "运镜", "镜头运动"],
    subject: ["subject", "主体", "人物主体"],
    action: ["action", "action_expression", "动作", "动作表情"],
    scene: ["scene", "场景", "环境"],
    composition: ["composition", "构图"],
    lighting: ["lighting", "光线", "光影"],
    color: ["color", "色彩", "颜色"],
    style: ["style", "art_style", "风格", "艺术风格"],
    screenText: ["screenText", "screen_text", "画面文字", "屏幕文字"],
    dialogue: ["dialogue", "对白", "台词"],
    sound: ["sound", "sound_effect", "音效", "声音"],
    uncertainties: ["uncertainties", "不确定项", "不确定性"],
    confidence: ["confidence", "置信度"],
    description: ["description", "visual_description", "画面描述", "视觉描述"]
  };

  const SYSTEM_PROMPT = `你是 Gary Prompt 的专业视频镜头分析器。用户提供的是按均匀时间间隔从视频中抽出的静态帧，每张图都带有视频名与时间戳。

必须遵守：
1. 逐帧分析并保持输入顺序，只输出 JSON 数组，不输出 Markdown、解释或代码围栏。
2. 单张静态帧不能证明真实运镜。cameraMovement 只能写“静态帧无法确认；推测：……”或“静态帧无法确认”。
3. 没有音频输入，dialogue 固定写“未分析/需要音频转写”，sound 固定写“未分析/需要音频转写”。
4. 不把相邻帧之间的变化伪装成已确认的连续动作；动作趋势必须标注“推测”。
5. 看不清的内容写入 uncertainties，禁止编造人物身份、品牌、地点、对白或画外事件。
6. 每一项必须包含 frameIndex、timestamp、shotType、cameraMovement、subject、action、scene、composition、lighting、color、style、screenText、dialogue、sound、uncertainties、confidence、description。
7. confidence 使用 0 到 1 的小数。description 是简洁、可复用的镜头画面描述。`;

  function buildBatchPrompt(videoName, frames, userFocus, language) {
    const mapping = frames.map((frame, index) =>
      `输入图像 ${index + 1}：frameIndex=${frame.frameIndex}，timestamp=${frame.time.toFixed(2)}s`
    ).join("\n");
    return `请用 ${language || "简体中文"} 分析视频《${videoName}》的以下均匀抽帧。\n${mapping}\n\n用户补充的分析重点：${userFocus || "无，请执行完整镜头分析。"}\n\n只返回与输入图像数量一致、顺序一致的 JSON 数组。`;
  }

  function extractJsonArray(raw) {
    const cleaned = String(raw || "").replace(/^\s*```(?:json)?/i, "").replace(/```\s*$/, "").trim();
    const start = cleaned.indexOf("[");
    const end = cleaned.lastIndexOf("]");
    if (start < 0 || end <= start) throw new Error("模型没有返回可识别的 JSON 数组，请重试或更换模型。");
    try { return JSON.parse(cleaned.slice(start, end + 1)); }
    catch (_) { throw new Error("模型返回的 JSON 格式不完整，请重试。"); }
  }

  function firstValue(row, aliases) {
    for (const key of aliases) {
      if (row?.[key] !== undefined && row[key] !== null && String(row[key]).trim()) return row[key];
    }
    return "";
  }

  function normalizeRow(row, frame, videoName) {
    const normalized = {
      video: videoName,
      frameIndex: Number(row?.frameIndex ?? row?.frame_index ?? frame.frameIndex),
      timestamp: Number(row?.timestamp ?? row?.time ?? frame.time)
    };
    FIELDS.forEach(field => { normalized[field] = String(firstValue(row, FIELD_ALIASES[field]) || "未识别").trim(); });
    if (!/未分析|转写/.test(normalized.dialogue)) normalized.dialogue = "未分析/需要音频转写";
    if (!/未分析|转写/.test(normalized.sound)) normalized.sound = "未分析/需要音频转写";
    if (!/无法确认|推测/.test(normalized.cameraMovement)) normalized.cameraMovement = `静态帧无法确认；推测：${normalized.cameraMovement}`;
    const confidence = Number(normalized.confidence);
    normalized.confidence = Number.isFinite(confidence) ? Math.max(0, Math.min(1, confidence)).toFixed(2) : "未提供";
    if (!Number.isFinite(normalized.timestamp)) normalized.timestamp = frame.time;
    return normalized;
  }

  function parseBatch(raw, frames, videoName) {
    const rows = extractJsonArray(raw);
    if (!Array.isArray(rows) || !rows.length) throw new Error("模型返回了空的镜头分析结果。");
    return frames.map((frame, index) => normalizeRow(rows[index] || {}, frame, videoName));
  }

  function escapeCell(value) {
    return String(value ?? "").replace(/\|/g, "\\|").replace(/\r?\n/g, "<br>");
  }

  function markdownTable(rows, meta) {
    const head = `# 视频解析：${meta.videoName}\n\n- 时长：${meta.duration.toFixed(2)} 秒\n- 均匀间隔：${meta.interval} 秒\n- 抽帧：${rows.length} 帧（各时间段中点）\n- 音频：未分析，需要单独转写\n\n`;
    const columns = [
      ["时间", row => `${Number(row.timestamp).toFixed(2)}s`],
      ["景别", row => row.shotType],
      ["运镜", row => row.cameraMovement],
      ["主体", row => row.subject],
      ["动作/表情", row => row.action],
      ["场景", row => row.scene],
      ["构图", row => row.composition],
      ["光影/色彩", row => `${row.lighting}；${row.color}`],
      ["风格", row => row.style],
      ["画面描述", row => row.description],
      ["不确定项", row => row.uncertainties],
      ["置信度", row => row.confidence]
    ];
    return head + `| ${columns.map(item => item[0]).join(" | ")} |\n| ${columns.map(() => "---").join(" | ")} |\n` +
      rows.map(row => `| ${columns.map(item => escapeCell(item[1](row))).join(" | ")} |`).join("\n");
  }

  function markdownDocument(rows, meta) {
    const parts = [
      `# 视频解析文档：${meta.videoName}`,
      "",
      `**基础信息**：时长 ${meta.duration.toFixed(2)} 秒；按 ${meta.interval} 秒均匀分段并取中点，共 ${rows.length} 帧。`,
      "",
      "> 说明：本结果来自静态抽帧。运镜和连续动作只能推测；对白与音效未分析，需要单独进行音频转写。"
    ];
    rows.forEach((row, index) => {
      parts.push(
        "",
        `## ${index + 1}. ${Number(row.timestamp).toFixed(2)} 秒`,
        "",
        `- 景别：${row.shotType}`,
        `- 运镜：${row.cameraMovement}`,
        `- 主体：${row.subject}`,
        `- 动作/表情：${row.action}`,
        `- 场景与构图：${row.scene}；${row.composition}`,
        `- 光影与色彩：${row.lighting}；${row.color}`,
        `- 风格：${row.style}`,
        `- 画面文字：${row.screenText}`,
        `- 对白：${row.dialogue}`,
        `- 音效：${row.sound}`,
        `- 画面描述：${row.description}`,
        `- 不确定项：${row.uncertainties}`,
        `- 置信度：${row.confidence}`
      );
    });
    return parts.join("\n");
  }

  function csv(rows) {
    const columns = [
      ["视频", "video"], ["帧序号", "frameIndex"], ["时间(秒)", "timestamp"], ["景别", "shotType"],
      ["运镜", "cameraMovement"], ["主体", "subject"], ["动作/表情", "action"], ["场景", "scene"],
      ["构图", "composition"], ["光影", "lighting"], ["色彩", "color"], ["风格", "style"],
      ["画面文字", "screenText"], ["对白", "dialogue"], ["音效", "sound"], ["不确定项", "uncertainties"],
      ["置信度", "confidence"], ["画面描述", "description"]
    ];
    const quote = value => `"${String(value ?? "").replace(/"/g, '""')}"`;
    return [columns.map(item => quote(item[0])).join(","), ...rows.map(row => columns.map(item => quote(row[item[1]])).join(","))].join("\r\n");
  }

  window.GaryVideoAnalysis = { SYSTEM_PROMPT, buildBatchPrompt, parseBatch, markdownTable, markdownDocument, csv };
})();
